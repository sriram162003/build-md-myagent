// src/tools/search.ts

import axios from 'axios';
import { Tool } from '../types.js';

async function braveSearch(query: string, count = 5): Promise<string> {
  const apiKey = process.env.BRAVE_API_KEY;
  if (!apiKey) throw new Error('No Brave API key');

  const res = await axios.get('https://api.search.brave.com/res/v1/web/search', {
    headers: {
      'Accept': 'application/json',
      'Accept-Encoding': 'gzip',
      'X-Subscription-Token': apiKey,
    },
    params: { q: query, count },
    timeout: 10000,
  });

  const results = res.data?.web?.results || [];
  if (results.length === 0) return 'No results found.';

  return results.slice(0, count).map((r: { title: string; url: string; description?: string }, i: number) =>
    `[${i + 1}] **${r.title}**\n${r.url}\n${r.description || ''}`
  ).join('\n\n');
}

async function duckDuckGoSearch(query: string): Promise<string> {
  // Use DDG's instant answer API (limited but free, no key needed)
  const res = await axios.get('https://api.duckduckgo.com/', {
    params: {
      q: query,
      format: 'json',
      no_redirect: 1,
      no_html: 1,
      skip_disambig: 1,
    },
    timeout: 8000,
  });

  const data = res.data;
  const parts: string[] = [];

  if (data.AbstractText) {
    parts.push(`**Summary:** ${data.AbstractText}`);
    if (data.AbstractURL) parts.push(`Source: ${data.AbstractURL}`);
  }

  if (data.RelatedTopics?.length > 0) {
    parts.push('\n**Related:**');
    data.RelatedTopics.slice(0, 4).forEach((t: { Text?: string; FirstURL?: string }) => {
      if (t.Text) parts.push(`• ${t.Text}`);
    });
  }

  if (data.Answer) {
    parts.unshift(`**Quick Answer:** ${data.Answer}`);
  }

  if (parts.length === 0) {
    return `No instant answer found for: "${query}". Try Brave API for full web results.`;
  }

  return parts.join('\n');
}

export const searchTool: Tool = {
  name: 'web_search',
  description: 'Search the web for current information, news, facts, or any topic. Use this when you need up-to-date or external information.',
  input_schema: {
    type: 'object',
    properties: {
      query: {
        type: 'string',
        description: 'The search query. Be specific and concise for best results.',
      },
      count: {
        type: 'number',
        description: 'Number of results to return (1-10, default 5)',
      },
    },
    required: ['query'],
  },
  async execute({ query, count = 5 }: { query: string; count?: number }) {
    console.log(`[Search] Searching: "${query}"`);
    try {
      if (process.env.BRAVE_API_KEY) {
        return await braveSearch(query, Math.min(count, 10));
      }
      return await duckDuckGoSearch(query);
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      return `Search failed: ${msg}. Please set BRAVE_API_KEY for full web search.`;
    }
  },
};

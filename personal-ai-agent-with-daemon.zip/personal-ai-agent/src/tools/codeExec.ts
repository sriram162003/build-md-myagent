// src/tools/codeExec.ts
// Sandboxed code execution using Node's built-in `vm` module.

import vm from 'vm';
import { Tool } from '../types.js';

const TIMEOUT_MS = 10_000; // 10 seconds max
const MAX_OUTPUT = 4000;   // Max chars in output

function truncate(s: string, max = MAX_OUTPUT): string {
  if (s.length <= max) return s;
  return s.slice(0, max) + `\n... [truncated ${s.length - max} chars]`;
}

function safeStringify(val: unknown): string {
  if (val === undefined) return 'undefined';
  if (val === null) return 'null';
  if (typeof val === 'function') return val.toString();
  try {
    return JSON.stringify(val, null, 2);
  } catch {
    return String(val);
  }
}

async function runJavaScript(code: string): Promise<string> {
  const logs: string[] = [];
  const errors: string[] = [];

  const sandbox = {
    console: {
      log: (...args: unknown[]) => logs.push(args.map(safeStringify).join(' ')),
      error: (...args: unknown[]) => errors.push(args.map(safeStringify).join(' ')),
      warn: (...args: unknown[]) => logs.push('[warn] ' + args.map(safeStringify).join(' ')),
      info: (...args: unknown[]) => logs.push('[info] ' + args.map(safeStringify).join(' ')),
    },
    Math,
    JSON,
    Date,
    Array,
    Object,
    String,
    Number,
    Boolean,
    RegExp,
    Error,
    Map,
    Set,
    Promise,
    setTimeout: undefined,  // Disable to prevent event loop abuse
    setInterval: undefined,
    fetch: undefined,        // No network access from code sandbox
    require: undefined,      // No require
    process: undefined,      // No process access
    __dirname: undefined,
    __filename: undefined,
  };

  vm.createContext(sandbox);

  let result: unknown;
  let execError: string | null = null;

  try {
    // Wrap in async IIFE to support top-level await
    const wrapped = `(async () => { ${code} })()`;
    const script = new vm.Script(wrapped);
    result = await script.runInContext(sandbox, { timeout: TIMEOUT_MS });
  } catch (err) {
    execError = err instanceof Error ? err.message : String(err);
  }

  const output: string[] = [];

  if (logs.length > 0) {
    output.push('**Output:**\n```\n' + logs.join('\n') + '\n```');
  }
  if (errors.length > 0) {
    output.push('**Errors:**\n```\n' + errors.join('\n') + '\n```');
  }
  if (execError) {
    output.push('**Execution Error:**\n```\n' + execError + '\n```');
  }
  if (result !== undefined && result !== null) {
    const val = safeStringify(result);
    if (val !== 'undefined') {
      output.push('**Return Value:**\n```\n' + val + '\n```');
    }
  }

  if (output.length === 0) {
    output.push('Code executed successfully (no output).');
  }

  return truncate(output.join('\n\n'));
}

export const codeExecTool: Tool = {
  name: 'execute_code',
  description: 'Execute JavaScript code in a sandboxed environment. Supports math, data processing, algorithms, string manipulation, and more. Use console.log() to output results. No network or file access within the sandbox.',
  input_schema: {
    type: 'object',
    properties: {
      code: {
        type: 'string',
        description: 'JavaScript code to execute. Use console.log() to print results.',
      },
      language: {
        type: 'string',
        enum: ['javascript'],
        description: 'Programming language (only JavaScript supported)',
      },
    },
    required: ['code'],
  },
  async execute({ code }: { code: string }) {
    console.log(`[Code] Executing ${code.split('\n').length} lines`);
    return runJavaScript(code);
  },
};

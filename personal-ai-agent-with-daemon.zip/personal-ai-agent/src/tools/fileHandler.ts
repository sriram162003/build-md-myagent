// src/tools/fileHandler.ts

import fs from 'fs';
import path from 'path';
import { Tool } from '../types.js';

const FILES_DIR = path.resolve(process.env.FILES_DIR || './agent-files', 'files');
const MAX_FILE_SIZE = (parseInt(process.env.MAX_FILE_SIZE_MB || '10') * 1024 * 1024);

function ensureDir(): void {
  if (!fs.existsSync(FILES_DIR)) {
    fs.mkdirSync(FILES_DIR, { recursive: true });
  }
}

function sanitizeName(name: string): string {
  // Strip path traversal and only allow safe filenames
  return path.basename(name).replace(/[^a-zA-Z0-9._\-]/g, '_');
}

function safePath(name: string): string {
  const safe = sanitizeName(name);
  const full = path.join(FILES_DIR, safe);
  // Ensure within FILES_DIR (path traversal protection)
  if (!full.startsWith(FILES_DIR)) throw new Error('Invalid filename');
  return full;
}

export const saveFileTool: Tool = {
  name: 'save_file',
  description: 'Save text content to a named file. Useful for persisting data, notes, code, or any text content for later retrieval.',
  input_schema: {
    type: 'object',
    properties: {
      filename: {
        type: 'string',
        description: 'Filename (e.g. "notes.txt", "data.json", "script.js")',
      },
      content: {
        type: 'string',
        description: 'Text content to save',
      },
    },
    required: ['filename', 'content'],
  },
  async execute({ filename, content }: { filename: string; content: string }) {
    ensureDir();
    const filePath = safePath(filename);
    if (Buffer.byteLength(content) > MAX_FILE_SIZE) {
      return `Error: Content exceeds max size of ${process.env.MAX_FILE_SIZE_MB || 10}MB`;
    }
    fs.writeFileSync(filePath, content, 'utf-8');
    const sizeKB = (Buffer.byteLength(content) / 1024).toFixed(1);
    console.log(`[Files] Saved: ${filename} (${sizeKB}KB)`);
    return `✅ Saved "${sanitizeName(filename)}" (${sizeKB}KB)`;
  },
};

export const readFileTool: Tool = {
  name: 'read_file',
  description: 'Read the contents of a previously saved file.',
  input_schema: {
    type: 'object',
    properties: {
      filename: {
        type: 'string',
        description: 'Name of the file to read',
      },
    },
    required: ['filename'],
  },
  async execute({ filename }: { filename: string }) {
    ensureDir();
    const filePath = safePath(filename);
    if (!fs.existsSync(filePath)) {
      return `Error: File "${sanitizeName(filename)}" not found. Use list_files to see available files.`;
    }
    const content = fs.readFileSync(filePath, 'utf-8');
    const sizeKB = (Buffer.byteLength(content) / 1024).toFixed(1);
    console.log(`[Files] Read: ${filename} (${sizeKB}KB)`);
    if (content.length > 8000) {
      return `File "${filename}" (${sizeKB}KB) — first 8000 chars:\n\n${content.slice(0, 8000)}\n\n[... truncated]`;
    }
    return `📄 **${sanitizeName(filename)}** (${sizeKB}KB):\n\n${content}`;
  },
};

export const listFilesTool: Tool = {
  name: 'list_files',
  description: 'List all available saved files with their sizes and modification dates.',
  input_schema: {
    type: 'object',
    properties: {},
  },
  async execute() {
    ensureDir();
    const entries = fs.readdirSync(FILES_DIR).filter(f => !f.startsWith('.'));
    if (entries.length === 0) return 'No files saved yet.';
    const files = entries.map(name => {
      const stat = fs.statSync(path.join(FILES_DIR, name));
      const sizeKB = (stat.size / 1024).toFixed(1);
      const date = stat.mtime.toLocaleDateString();
      return `• ${name} — ${sizeKB}KB (${date})`;
    });
    return `📁 **Saved files (${files.length}):**\n${files.join('\n')}`;
  },
};

export const deleteFileTool: Tool = {
  name: 'delete_file',
  description: 'Delete a saved file.',
  input_schema: {
    type: 'object',
    properties: {
      filename: {
        type: 'string',
        description: 'Name of the file to delete',
      },
    },
    required: ['filename'],
  },
  async execute({ filename }: { filename: string }) {
    ensureDir();
    const filePath = safePath(filename);
    if (!fs.existsSync(filePath)) {
      return `Error: File "${sanitizeName(filename)}" not found.`;
    }
    fs.unlinkSync(filePath);
    console.log(`[Files] Deleted: ${filename}`);
    return `🗑️ Deleted "${sanitizeName(filename)}"`;
  },
};

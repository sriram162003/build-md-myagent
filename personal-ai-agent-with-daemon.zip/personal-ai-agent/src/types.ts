// src/types.ts

export type ChannelName = 'telegram' | 'discord' | 'slack' | 'webchat';

export interface Message {
  role: 'user' | 'assistant';
  content: string | ContentBlock[];
}

export interface ContentBlock {
  type: 'text' | 'tool_use' | 'tool_result';
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [key: string]: any;
}

export interface Session {
  id: string;
  channel: ChannelName;
  userId: string;
  username?: string;
  messages: Message[];
  createdAt: Date;
  updatedAt: Date;
}

export interface IncomingMessage {
  sessionId: string;
  channel: ChannelName;
  userId: string;
  username?: string;
  text: string;
  files?: UploadedFile[];
}

export interface UploadedFile {
  name: string;
  mimeType: string;
  data: Buffer;
  url?: string;
}

export interface AgentResponse {
  text: string;
  toolsUsed: string[];
}

export interface ChannelAdapter {
  name: ChannelName;
  start(): Promise<void>;
  stop(): Promise<void>;
  send(userId: string, text: string): Promise<void>;
}

export interface Tool {
  name: string;
  description: string;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  input_schema: Record<string, any>;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  execute(input: Record<string, any>): Promise<string>;
}

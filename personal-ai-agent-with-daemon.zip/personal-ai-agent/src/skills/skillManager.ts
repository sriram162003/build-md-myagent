// src/skills/skillManager.ts
// Manages all skill lifecycle: load from disk, save to disk, CRUD, search.

import fs from 'fs';
import path from 'path';
import { Skill, SkillFrontmatter, SkillResource, SkillSearchResult } from './types.js';

const SKILLS_ROOT = path.resolve(process.env.FILES_DIR || './agent-files', 'skills');
const SKILL_FILENAME = 'SKILL.md';

// ── YAML frontmatter parser (no deps) ──────────────────────────────────────
function parseFrontmatter(raw: string): { frontmatter: Partial<SkillFrontmatter>; body: string } {
  const fmMatch = raw.match(/^---\n([\s\S]*?)\n---\n?([\s\S]*)$/);
  if (!fmMatch) return { frontmatter: {}, body: raw };

  const yamlBlock = fmMatch[1];
  const body = fmMatch[2].trimStart();
  const frontmatter: Record<string, unknown> = {};

  for (const line of yamlBlock.split('\n')) {
    const colonIdx = line.indexOf(':');
    if (colonIdx < 0) continue;
    const key = line.slice(0, colonIdx).trim();
    let value: unknown = line.slice(colonIdx + 1).trim();

    // Parse booleans
    if (value === 'true') value = true;
    else if (value === 'false') value = false;
    // Parse arrays: [a, b, c] or - item lines
    else if (typeof value === 'string' && value.startsWith('[') && value.endsWith(']')) {
      value = (value as string)
        .slice(1, -1)
        .split(',')
        .map((s: string) => s.trim().replace(/^["']|["']$/g, ''));
    }
    // Strip quotes from strings
    else if (typeof value === 'string') {
      value = (value as string).replace(/^["']|["']$/g, '');
    }

    if (key) frontmatter[key] = value;
  }

  return { frontmatter: frontmatter as Partial<SkillFrontmatter>, body };
}

function serializeFrontmatter(fm: SkillFrontmatter): string {
  const lines = [
    `name: ${fm.name}`,
    `description: "${fm.description.replace(/"/g, '\\"')}"`,
    `version: ${fm.version}`,
    `enabled: ${fm.enabled}`,
    `author: ${fm.author || 'agent'}`,
    `created: ${fm.created}`,
    `updated: ${fm.updated}`,
  ];
  if (fm.tags && fm.tags.length > 0) {
    lines.push(`tags: [${fm.tags.map(t => `"${t}"`).join(', ')}]`);
  }
  return `---\n${lines.join('\n')}\n---\n`;
}

function skillSlug(name: string): string {
  return name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
}

// ── SkillManager ───────────────────────────────────────────────────────────
class SkillManager {
  private skills: Map<string, Skill> = new Map();
  private initialized = false;

  private ensureRoot(): void {
    if (!fs.existsSync(SKILLS_ROOT)) {
      fs.mkdirSync(SKILLS_ROOT, { recursive: true });
    }
  }

  /** Load all skills from disk */
  async init(): Promise<void> {
    if (this.initialized) return;
    this.initialized = true;
    this.ensureRoot();
    this.loadAll();
    this.seedDefaults();
    console.log(`[Skills] Loaded ${this.skills.size} skills from ${SKILLS_ROOT}`);
  }

  private loadAll(): void {
    if (!fs.existsSync(SKILLS_ROOT)) return;
    const entries = fs.readdirSync(SKILLS_ROOT, { withFileTypes: true });
    for (const entry of entries) {
      if (!entry.isDirectory()) continue;
      try {
        this.loadSkill(entry.name);
      } catch (err) {
        console.warn(`[Skills] Failed to load skill "${entry.name}":`, err);
      }
    }
  }

  private loadSkill(dirName: string): void {
    const skillPath = path.join(SKILLS_ROOT, dirName, SKILL_FILENAME);
    if (!fs.existsSync(skillPath)) return;

    const raw = fs.readFileSync(skillPath, 'utf-8');
    const { frontmatter, body } = parseFrontmatter(raw);

    if (!frontmatter.name) frontmatter.name = dirName;
    if (frontmatter.enabled === undefined) frontmatter.enabled = true;
    if (!frontmatter.version) frontmatter.version = '1.0.0';
    if (!frontmatter.created) frontmatter.created = new Date().toISOString();
    if (!frontmatter.updated) frontmatter.updated = new Date().toISOString();

    // Load resources (non-SKILL.md files in subdirs)
    const resources: SkillResource[] = [];
    const skillDir = path.join(SKILLS_ROOT, dirName);
    this.loadResources(skillDir, skillDir, resources);

    const skill: Skill = {
      frontmatter: frontmatter as SkillFrontmatter,
      body,
      resources,
      path: skillPath,
    };

    this.skills.set(frontmatter.name as string, skill);
  }

  private loadResources(baseDir: string, dir: string, acc: SkillResource[]): void {
    if (!fs.existsSync(dir)) return;
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);
      const relPath = path.relative(baseDir, fullPath);
      if (entry.name === SKILL_FILENAME) continue;
      if (entry.isDirectory()) {
        this.loadResources(baseDir, fullPath, acc);
      } else {
        try {
          const content = fs.readFileSync(fullPath, 'utf-8');
          acc.push({ name: relPath, content });
        } catch { /* skip binary */ }
      }
    }
  }

  /** Write a skill to disk */
  private saveSkill(skill: Skill): void {
    const slug = skillSlug(skill.frontmatter.name);
    const skillDir = path.join(SKILLS_ROOT, slug);
    if (!fs.existsSync(skillDir)) fs.mkdirSync(skillDir, { recursive: true });

    const raw = serializeFrontmatter(skill.frontmatter) + '\n' + skill.body;
    fs.writeFileSync(path.join(skillDir, SKILL_FILENAME), raw, 'utf-8');

    // Write resources
    for (const resource of skill.resources) {
      const resourcePath = path.join(skillDir, resource.name);
      const resourceDir = path.dirname(resourcePath);
      if (!fs.existsSync(resourceDir)) fs.mkdirSync(resourceDir, { recursive: true });
      fs.writeFileSync(resourcePath, resource.content, 'utf-8');
    }

    skill.path = path.join(skillDir, SKILL_FILENAME);
  }

  // ── Public API ────────────────────────────────────────────────────────────

  /** Create a brand new skill */
  create(params: {
    name: string;
    description: string;
    body: string;
    tags?: string[];
    author?: string;
    resources?: SkillResource[];
  }): Skill {
    const slug = skillSlug(params.name);
    if (this.skills.has(params.name)) {
      throw new Error(`Skill "${params.name}" already exists. Use update() to modify it.`);
    }

    const now = new Date().toISOString();
    const skill: Skill = {
      frontmatter: {
        name: slug,
        description: params.description,
        version: '1.0.0',
        enabled: true,
        author: params.author || 'agent',
        tags: params.tags || [],
        created: now,
        updated: now,
      },
      body: params.body,
      resources: params.resources || [],
      path: '',
    };

    this.saveSkill(skill);
    this.skills.set(slug, skill);
    console.log(`[Skills] Created: ${slug}`);
    return skill;
  }

  /** Update an existing skill */
  update(name: string, patch: {
    description?: string;
    body?: string;
    tags?: string[];
    enabled?: boolean;
    resources?: SkillResource[];
    bumpVersion?: 'patch' | 'minor' | 'major';
  }): Skill {
    const slug = skillSlug(name);
    const skill = this.skills.get(slug);
    if (!skill) throw new Error(`Skill "${slug}" not found.`);

    if (patch.description !== undefined) skill.frontmatter.description = patch.description;
    if (patch.body !== undefined) skill.body = patch.body;
    if (patch.tags !== undefined) skill.frontmatter.tags = patch.tags;
    if (patch.enabled !== undefined) skill.frontmatter.enabled = patch.enabled;
    if (patch.resources !== undefined) skill.resources = patch.resources;

    // Bump version
    if (patch.bumpVersion) {
      const [maj, min, pat] = skill.frontmatter.version.split('.').map(Number);
      if (patch.bumpVersion === 'major') skill.frontmatter.version = `${maj + 1}.0.0`;
      else if (patch.bumpVersion === 'minor') skill.frontmatter.version = `${maj}.${min + 1}.0`;
      else skill.frontmatter.version = `${maj}.${min}.${pat + 1}`;
    } else {
      // Auto patch bump on any update
      const [maj, min, pat] = skill.frontmatter.version.split('.').map(Number);
      skill.frontmatter.version = `${maj}.${min}.${pat + 1}`;
    }

    skill.frontmatter.updated = new Date().toISOString();
    this.saveSkill(skill);
    console.log(`[Skills] Updated: ${slug} → v${skill.frontmatter.version}`);
    return skill;
  }

  /** Delete a skill */
  delete(name: string): void {
    const slug = skillSlug(name);
    const skill = this.skills.get(slug);
    if (!skill) throw new Error(`Skill "${slug}" not found.`);

    const skillDir = path.dirname(skill.path);
    fs.rmSync(skillDir, { recursive: true, force: true });
    this.skills.delete(slug);
    console.log(`[Skills] Deleted: ${slug}`);
  }

  /** Get a skill by name */
  get(name: string): Skill | undefined {
    return this.skills.get(skillSlug(name));
  }

  /** List all skills */
  list(options: { enabledOnly?: boolean; tags?: string[] } = {}): Skill[] {
    let skills = Array.from(this.skills.values());
    if (options.enabledOnly) skills = skills.filter(s => s.frontmatter.enabled);
    if (options.tags?.length) {
      skills = skills.filter(s =>
        options.tags!.some(t => s.frontmatter.tags?.includes(t))
      );
    }
    return skills.sort((a, b) => a.frontmatter.name.localeCompare(b.frontmatter.name));
  }

  /** Simple keyword search across name, description, body, and tags */
  search(query: string, limit = 10): SkillSearchResult[] {
    const terms = query.toLowerCase().split(/\s+/).filter(Boolean);
    const results: SkillSearchResult[] = [];

    for (const skill of this.skills.values()) {
      const matchedOn: string[] = [];
      let score = 0;

      const nameText = skill.frontmatter.name.toLowerCase();
      const descText = skill.frontmatter.description.toLowerCase();
      const bodyText = skill.body.toLowerCase();
      const tagsText = (skill.frontmatter.tags || []).join(' ').toLowerCase();

      for (const term of terms) {
        if (nameText.includes(term)) { score += 3; matchedOn.push('name'); }
        if (descText.includes(term)) { score += 2; matchedOn.push('description'); }
        if (tagsText.includes(term)) { score += 2; matchedOn.push('tags'); }
        if (bodyText.includes(term)) { score += 1; matchedOn.push('body'); }
      }

      if (score > 0) {
        results.push({ skill, score: score / (terms.length * 6), matchedOn: [...new Set(matchedOn)] });
      }
    }

    return results.sort((a, b) => b.score - a.score).slice(0, limit);
  }

  /** Build the context block injected into the system prompt */
  buildSystemContext(): string {
    const enabled = this.list({ enabledOnly: true });
    if (enabled.length === 0) return '';

    const registry = enabled.map(s =>
      `### ${s.frontmatter.name} (v${s.frontmatter.version})\n${s.frontmatter.description}`
    ).join('\n\n');

    return `
## Available Skills

You have ${enabled.length} skill(s) available. Skills are specialized capabilities you can invoke when relevant.
When a task matches a skill's description, READ the full skill body before proceeding.

${registry}

To use a skill, call \`read_skill\` with the skill name to load its full instructions.
To create/improve skills, use \`create_skill\`, \`update_skill\`, or \`list_skills\`.
`;
  }

  /** Get full skill content formatted for injection */
  getSkillContext(name: string): string {
    const skill = this.get(name);
    if (!skill) return `Skill "${name}" not found.`;

    let content = `## Skill: ${skill.frontmatter.name} (v${skill.frontmatter.version})\n\n${skill.body}`;

    if (skill.resources.length > 0) {
      content += '\n\n### Bundled Resources:\n';
      for (const r of skill.resources) {
        content += `\n**${r.name}:**\n\`\`\`\n${r.content}\n\`\`\`\n`;
      }
    }

    return content;
  }

  // ── Seed default skills ──────────────────────────────────────────────────
  private seedDefaults(): void {
    this.seedSkill(
      'code-reviewer',
      'Review code for bugs, security issues, and style problems. Trigger when user asks to review, audit, check, or analyze any code snippet or file.',
      ['code', 'review', 'security'],
      `## Code Review Process

When reviewing code, analyze it across these dimensions in order:

### 1. Correctness
- Logic errors, off-by-one errors, null/undefined handling
- Edge cases that could cause crashes or wrong results
- Incorrect algorithm complexity

### 2. Security
- Injection vulnerabilities (SQL, command, path traversal)
- Hardcoded secrets or credentials
- Improper input validation
- Insecure dependencies or patterns

### 3. Performance
- Unnecessary loops, redundant computation
- Memory leaks or excessive allocations
- Missing caching opportunities

### 4. Maintainability  
- Naming clarity, function length, complexity
- Missing error handling
- Lack of comments on non-obvious logic

### Output Format
Structure your review as:
- **Summary**: 1-2 sentence verdict
- **Critical Issues**: (if any) — must fix
- **Warnings**: Should fix
- **Suggestions**: Nice to have
- **Score**: X/10 with reasoning

Always provide fixed code snippets for critical issues.`
    );

    this.seedSkill(
      'research-assistant',
      'Deep research on any topic — searches multiple angles, synthesizes findings, cites sources. Trigger when user asks to research, investigate, summarize, or compare topics.',
      ['research', 'search', 'web'],
      `## Research Process

### Phase 1: Query Planning
Break the research goal into 3-5 distinct search queries covering:
- Core definition/overview
- Recent developments (add current year to query)
- Different perspectives or alternatives  
- Practical implications

### Phase 2: Search & Gather
Run searches in sequence. For each result:
- Extract key facts and quotes
- Note source credibility
- Identify contradictions between sources

### Phase 3: Synthesis
Structure findings as:
1. **Overview** — What is this? Core definition
2. **Key Findings** — Most important points (bullet list)
3. **Details** — Expand on each key finding with evidence
4. **Conflicting Views** — Where sources disagree
5. **Conclusion** — Your synthesis and assessment

Always cite sources inline. Flag uncertainty explicitly.`
    );

    this.seedSkill(
      'data-analyst',
      'Analyze data, compute statistics, generate insights from numbers, tables, or datasets. Trigger when user shares data, numbers, CSV content, or asks for analysis, trends, or patterns.',
      ['data', 'analysis', 'statistics', 'math'],
      `## Data Analysis Workflow

### Step 1: Understand the Data
- What format is it in? (CSV, JSON, list, table)
- What are the columns/fields?
- What question is the user trying to answer?

### Step 2: Clean & Validate
Use execute_code to:
- Check for missing values, outliers, duplicates
- Validate data types
- Note any data quality issues

### Step 3: Compute
Run appropriate analysis:
- **Descriptive**: mean, median, mode, std dev, range
- **Trend**: sort by date/index, compute deltas, moving averages
- **Comparison**: group by category, compute ratios
- **Correlation**: find relationships between variables

### Step 4: Insights
Always produce:
- 3-5 key findings in plain English
- The single most important insight highlighted
- What action should the user take based on this data?

### Code Pattern
\`\`\`javascript
const data = [/* user's data */];
const sum = data.reduce((a, b) => a + b, 0);
const mean = sum / data.length;
const sorted = [...data].sort((a, b) => a - b);
const median = sorted[Math.floor(sorted.length / 2)];
console.log({ count: data.length, sum, mean, median });
\`\`\`
Save analysis results with save_file for later reference.`
    );

    this.seedSkill(
      'skill-writer',
      'Create, improve, or update agent skills. Trigger when user asks to create a skill, save a workflow as a skill, teach the agent something, or when you identify a reusable pattern worth capturing as a skill.',
      ['skills', 'meta', 'self-improvement', 'learning'],
      `## How to Write a Skill

Skills are markdown files that teach you (the agent) specialized workflows.
A great skill captures hard-won knowledge so you don't have to figure it out from scratch each time.

### When to Create a Skill
- User explicitly asks ("save this as a skill", "remember how to do this")
- You solve a complex multi-step problem — capture the pattern
- A task recurs across sessions
- You discover a reliable pattern through trial and error

### Skill Anatomy

\`\`\`markdown
---
name: skill-name-in-kebab-case
description: "When to trigger. Be specific and a bit pushy — include 
              synonyms users might say. E.g.: Trigger when user asks to X, Y, or Z."
version: 1.0.0
tags: [tag1, tag2]
---

## Purpose
One paragraph describing what this skill enables.

## Process
Step-by-step numbered instructions.

## Examples
Concrete examples of input → output.

## Edge Cases
What to watch out for.
\`\`\`

### Quality Checklist
- [ ] Description mentions 3+ trigger phrases
- [ ] Steps are concrete and ordered
- [ ] Includes at least one example
- [ ] No unnecessary prose — every sentence helps
- [ ] Under 400 lines (add resource files for longer content)

### Self-Improvement Protocol
After completing a complex task:
1. Identify what went well and what was surprising
2. Capture the winning approach in a skill
3. Note any tools that were useful
4. Add edge cases you encountered

Use create_skill or update_skill to persist the knowledge.`
    );
  }

  private seedSkill(name: string, description: string, tags: string[], body: string): void {
    const slug = skillSlug(name);
    if (!this.skills.has(slug)) {
      try {
        this.create({ name: slug, description, body, tags, author: 'system' });
      } catch { /* already exists */ }
    }
  }
}

export const skillManager = new SkillManager();

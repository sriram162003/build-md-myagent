// src/skills/skillTools.ts
// Tools that allow the agent to create, read, update, delete, list, and search skills.

import { Tool } from '../types.js';
import { skillManager } from './skillManager.js';

export const createSkillTool: Tool = {
  name: 'create_skill',
  description: `Create a new skill — a persistent knowledge module that gets injected into future conversations.
Use this when:
- A user asks you to "save this workflow", "remember how to do X", or "create a skill"
- You solve a complex task and want to capture the approach for reuse
- A recurring pattern is worth codifying
Skills persist across all sessions and channels.`,
  input_schema: {
    type: 'object',
    properties: {
      name: {
        type: 'string',
        description: 'Unique skill name in kebab-case (e.g., "web-scraper", "sql-helper")',
      },
      description: {
        type: 'string',
        description: 'When to trigger this skill. Be specific — include trigger phrases and contexts. This is what determines if the skill gets auto-loaded.',
      },
      body: {
        type: 'string',
        description: 'The full skill content in markdown. Include: purpose, step-by-step process, examples, edge cases. Under 400 lines ideal.',
      },
      tags: {
        type: 'array',
        items: { type: 'string' },
        description: 'Keywords for searching (e.g. ["code", "python", "web"])',
      },
      resources: {
        type: 'array',
        description: 'Optional bundled files (scripts, reference docs)',
        items: {
          type: 'object',
          properties: {
            name: { type: 'string', description: 'Relative path (e.g. "scripts/helper.js")' },
            content: { type: 'string', description: 'File content' },
          },
          required: ['name', 'content'],
        },
      },
    },
    required: ['name', 'description', 'body'],
  },
  async execute({ name, description, body, tags, resources }: {
    name: string; description: string; body: string; tags?: string[]; resources?: { name: string; content: string }[];
  }) {
    const skill = skillManager.create({ name, description, body, tags, resources, author: 'agent' });
    return `✅ Skill "${skill.frontmatter.name}" created (v${skill.frontmatter.version})\n\nDescription: ${skill.frontmatter.description}\nTags: ${(skill.frontmatter.tags || []).join(', ') || 'none'}\n\nThis skill will be available in all future conversations.`;
  },
};

export const updateSkillTool: Tool = {
  name: 'update_skill',
  description: `Update an existing skill — improve its instructions, fix errors, extend coverage, or adjust its trigger description.
Use when a skill's approach needs refinement, when you've found a better method, or when a user provides feedback.`,
  input_schema: {
    type: 'object',
    properties: {
      name: {
        type: 'string',
        description: 'Name of the skill to update',
      },
      description: {
        type: 'string',
        description: 'Updated trigger description (optional)',
      },
      body: {
        type: 'string',
        description: 'Updated skill body in markdown (optional — if omitted, keeps existing body)',
      },
      tags: {
        type: 'array',
        items: { type: 'string' },
        description: 'Updated tags (optional)',
      },
      enabled: {
        type: 'boolean',
        description: 'Enable or disable the skill (optional)',
      },
      bump: {
        type: 'string',
        enum: ['patch', 'minor', 'major'],
        description: 'Version bump type (defaults to patch)',
      },
    },
    required: ['name'],
  },
  async execute({ name, description, body, tags, enabled, bump }: {
    name: string; description?: string; body?: string; tags?: string[]; enabled?: boolean; bump?: 'patch' | 'minor' | 'major';
  }) {
    const skill = skillManager.update(name, {
      description,
      body,
      tags,
      enabled,
      bumpVersion: bump || 'patch',
    });
    return `✅ Skill "${skill.frontmatter.name}" updated → v${skill.frontmatter.version}\n\nChanges applied at ${new Date(skill.frontmatter.updated).toLocaleString()}`;
  },
};

export const readSkillTool: Tool = {
  name: 'read_skill',
  description: `Read a skill's full content and instructions. Use this when a task matches a skill's description — load it to get the detailed workflow before proceeding.`,
  input_schema: {
    type: 'object',
    properties: {
      name: {
        type: 'string',
        description: 'Skill name to read',
      },
    },
    required: ['name'],
  },
  async execute({ name }: { name: string }) {
    const content = skillManager.getSkillContext(name);
    return content;
  },
};

export const listSkillsTool: Tool = {
  name: 'list_skills',
  description: `List all available skills with their names, descriptions, versions, and status. Use to discover what skills exist before creating a duplicate, or to show the user what capabilities are available.`,
  input_schema: {
    type: 'object',
    properties: {
      enabledOnly: {
        type: 'boolean',
        description: 'If true, only show enabled skills (default: false)',
      },
      tags: {
        type: 'array',
        items: { type: 'string' },
        description: 'Filter by tags (optional)',
      },
    },
  },
  async execute({ enabledOnly, tags }: { enabledOnly?: boolean; tags?: string[] } = {}) {
    const skills = skillManager.list({ enabledOnly, tags });
    if (skills.length === 0) return 'No skills found.';

    const lines = skills.map(s => {
      const status = s.frontmatter.enabled ? '🟢' : '🔴';
      const tagStr = s.frontmatter.tags?.length ? ` [${s.frontmatter.tags.join(', ')}]` : '';
      const author = s.frontmatter.author ? ` • by ${s.frontmatter.author}` : '';
      return `${status} **${s.frontmatter.name}** v${s.frontmatter.version}${tagStr}${author}\n   ${s.frontmatter.description.slice(0, 120)}${s.frontmatter.description.length > 120 ? '...' : ''}`;
    });

    return `📚 **Skills (${skills.length} total):**\n\n${lines.join('\n\n')}`;
  },
};

export const searchSkillsTool: Tool = {
  name: 'search_skills',
  description: `Search skills by keyword. Use before creating a new skill to check if a similar one exists, or to find relevant skills for a task.`,
  input_schema: {
    type: 'object',
    properties: {
      query: {
        type: 'string',
        description: 'Search terms (searched across name, description, tags, and body)',
      },
    },
    required: ['query'],
  },
  async execute({ query }: { query: string }) {
    const results = skillManager.search(query);
    if (results.length === 0) return `No skills matched "${query}". Consider creating one with create_skill.`;

    const lines = results.map(r => {
      const score = Math.round(r.score * 100);
      return `**${r.skill.frontmatter.name}** (${score}% match, matched: ${r.matchedOn.join(', ')})\n${r.skill.frontmatter.description.slice(0, 100)}...`;
    });

    return `🔍 **Search results for "${query}":**\n\n${lines.join('\n\n')}`;
  },
};

export const deleteSkillTool: Tool = {
  name: 'delete_skill',
  description: `Permanently delete a skill. Use only when a skill is no longer useful, outdated, or has been superseded by a better one.`,
  input_schema: {
    type: 'object',
    properties: {
      name: {
        type: 'string',
        description: 'Name of the skill to delete',
      },
      confirm: {
        type: 'boolean',
        description: 'Must be true to confirm deletion',
      },
    },
    required: ['name', 'confirm'],
  },
  async execute({ name, confirm }: { name: string; confirm: boolean }) {
    if (!confirm) return 'Deletion cancelled — set confirm: true to proceed.';
    skillManager.delete(name);
    return `🗑️ Skill "${name}" permanently deleted.`;
  },
};

export const exportSkillTool: Tool = {
  name: 'export_skill',
  description: `Export a skill as a formatted markdown string — useful for sharing, backing up, or reviewing a skill in full detail.`,
  input_schema: {
    type: 'object',
    properties: {
      name: { type: 'string', description: 'Skill name to export' },
    },
    required: ['name'],
  },
  async execute({ name }: { name: string }) {
    const skill = skillManager.get(name);
    if (!skill) return `Skill "${name}" not found.`;

    const fm = skill.frontmatter;
    const header = `# Skill: ${fm.name}\n\n**Version:** ${fm.version}  \n**Author:** ${fm.author || 'unknown'}  \n**Tags:** ${(fm.tags || []).join(', ') || 'none'}  \n**Created:** ${new Date(fm.created).toLocaleDateString()}  \n**Updated:** ${new Date(fm.updated).toLocaleDateString()}  \n\n**Trigger Description:**\n> ${fm.description}\n\n---\n\n`;

    return header + skill.body;
  },
};

export const allSkillTools = [
  createSkillTool,
  updateSkillTool,
  readSkillTool,
  listSkillsTool,
  searchSkillsTool,
  deleteSkillTool,
  exportSkillTool,
];

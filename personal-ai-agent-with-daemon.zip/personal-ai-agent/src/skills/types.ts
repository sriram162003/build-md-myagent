// src/skills/types.ts

export interface SkillFrontmatter {
  name: string;                 // Unique identifier (slug)
  description: string;          // When & why to trigger this skill (the LLM reads this)
  version: string;              // semver, starts at "1.0.0"
  author?: string;              // "agent" | "user" | username
  tags?: string[];              // For searching/categorization
  created: string;              // ISO date
  updated: string;              // ISO date
  enabled: boolean;             // Whether to inject into system prompt
}

export interface Skill {
  frontmatter: SkillFrontmatter;
  body: string;                 // The markdown instructions
  resources: SkillResource[];   // Bundled files (scripts, references, etc.)
  path: string;                 // Absolute path to SKILL.md on disk
}

export interface SkillResource {
  name: string;                 // Relative path from skill root
  content: string;
}

export interface SkillSearchResult {
  skill: Skill;
  score: number;                // Relevance score 0–1
  matchedOn: string[];          // Which fields matched
}

// src/providers/ollama.ts
// Ollama provider — supports local models like llama3, mistral, qwen, etc.
// Uses Ollama's native tool-calling API (supported in Ollama 0.3+)
// Falls back to prompt-injected tool calling for older versions or models that don't support it.

import type { LLMProvider, LLMMessage, LLMTool, LLMResponse, LLMToolCall } from './types.js';

const OLLAMA_BASE_URL = process.env.OLLAMA_BASE_URL || 'http://localhost:11434';
const OLLAMA_MODEL = process.env.LLM_MODEL || 'llama3.2';

// ── Prompt-injection fallback ────────────────────────────────────────────────
// When native tool calling isn't available, we inject tool definitions into
// the system prompt and parse JSON tool calls from the model's text output.

function buildToolPrompt(tools: LLMTool[]): string {
  if (tools.length === 0) return '';

  const toolDefs = tools.map(t => {
    const props = t.input_schema['properties'] as Record<string, { type: string; description?: string }> || {};
    const required = (t.input_schema['required'] as string[]) || [];
    const params = Object.entries(props)
      .map(([k, v]) => `    - ${k} (${v.type}${required.includes(k) ? ', required' : ''}): ${v.description || ''}`)
      .join('\n');
    return `### ${t.name}\n${t.description}\nParameters:\n${params}`;
  }).join('\n\n');

  return `\n\n## Available Tools\nYou can call tools by responding with a JSON block in this exact format (and nothing else on that line):\n\`\`\`tool_call\n{"tool": "tool_name", "input": {"param": "value"}}\n\`\`\`\n\nOnly call one tool at a time. Wait for the result before calling another.\n\n${toolDefs}\n\nIf you don't need a tool, just respond normally.`;
}

function parseToolCall(text: string): LLMToolCall | null {
  // Match ```tool_call ... ``` blocks
  const match = text.match(/```tool_call\s*([\s\S]*?)```/);
  if (!match) return null;
  try {
    const parsed = JSON.parse(match[1].trim());
    if (parsed.tool && typeof parsed.tool === 'string') {
      return {
        id: `tool_${Date.now()}`,
        name: parsed.tool,
        input: parsed.input || {},
      };
    }
  } catch {
    // not valid JSON
  }
  return null;
}

// ── Native Ollama tool calling ───────────────────────────────────────────────

interface OllamaToolDef {
  type: 'function';
  function: {
    name: string;
    description: string;
    parameters: Record<string, unknown>;
  };
}

interface OllamaMessage {
  role: string;
  content: string;
  tool_calls?: Array<{
    function: { name: string; arguments: Record<string, unknown> };
  }>;
  tool_call_id?: string;
}

async function chatWithNativeTools(
  messages: LLMMessage[],
  tools: LLMTool[],
  systemPrompt: string,
): Promise<LLMResponse | null> {
  const ollamaTools: OllamaToolDef[] = tools.map(t => ({
    type: 'function',
    function: {
      name: t.name,
      description: t.description,
      parameters: t.input_schema,
    },
  }));

  const msgs: OllamaMessage[] = [
    { role: 'system', content: systemPrompt },
    ...messages.map(m => ({ role: m.role, content: m.content })),
  ];

  const res = await fetch(`${OLLAMA_BASE_URL}/api/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: OLLAMA_MODEL,
      messages: msgs,
      tools: ollamaTools,
      stream: false,
    }),
  });

  if (!res.ok) return null;

  const data = await res.json() as {
    message?: {
      content?: string;
      tool_calls?: Array<{ function: { name: string; arguments: Record<string, unknown> } }>;
    };
  };

  const msg = data.message;
  if (!msg) return null;

  if (msg.tool_calls && msg.tool_calls.length > 0) {
    return {
      text: msg.content || '',
      stopReason: 'tool_use',
      toolCalls: msg.tool_calls.map((tc, i) => ({
        id: `tool_${Date.now()}_${i}`,
        name: tc.function.name,
        input: tc.function.arguments,
      })),
    };
  }

  return { text: msg.content || '', toolCalls: [], stopReason: 'end_turn' };
}

async function chatWithPromptTools(
  messages: LLMMessage[],
  tools: LLMTool[],
  systemPrompt: string,
): Promise<LLMResponse> {
  const enhancedSystem = systemPrompt + buildToolPrompt(tools);

  const msgs = [
    { role: 'system', content: enhancedSystem },
    ...messages.map(m => ({ role: m.role, content: m.content })),
  ];

  const res = await fetch(`${OLLAMA_BASE_URL}/api/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ model: OLLAMA_MODEL, messages: msgs, stream: false }),
  });

  if (!res.ok) {
    throw new Error(`Ollama error: ${res.status} ${await res.text()}`);
  }

  const data = await res.json() as { message?: { content?: string } };
  const text = data.message?.content || '';

  const toolCall = parseToolCall(text);
  if (toolCall) {
    return { text: '', stopReason: 'tool_use', toolCalls: [toolCall] };
  }

  return { text, toolCalls: [], stopReason: 'end_turn' };
}

// ── OllamaProvider ───────────────────────────────────────────────────────────

export class OllamaProvider implements LLMProvider {
  name = 'ollama';
  private useNativeTools: boolean;

  constructor() {
    // Default to native tools — disable with OLLAMA_NATIVE_TOOLS=false
    this.useNativeTools = process.env.OLLAMA_NATIVE_TOOLS !== 'false';
  }

  async chat(messages: LLMMessage[], tools: LLMTool[], systemPrompt: string): Promise<LLMResponse> {
    if (this.useNativeTools && tools.length > 0) {
      // Try native tool calling first
      const result = await chatWithNativeTools(messages, tools, systemPrompt);
      if (result) return result;
      // Fall back to prompt injection if native fails
      console.warn('[Ollama] Native tool calling failed, falling back to prompt injection');
    }
    return chatWithPromptTools(messages, tools, systemPrompt);
  }
}

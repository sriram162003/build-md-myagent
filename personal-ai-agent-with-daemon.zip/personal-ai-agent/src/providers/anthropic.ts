// src/providers/anthropic.ts
// Claude provider using the official Anthropic SDK

import Anthropic from '@anthropic-ai/sdk';
import type { LLMProvider, LLMMessage, LLMTool, LLMResponse } from './types.js';

export class AnthropicProvider implements LLMProvider {
  name = 'anthropic';
  private client: Anthropic;
  private model: string;

  constructor() {
    this.client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
    this.model = process.env.LLM_MODEL || 'claude-opus-4-6';
  }

  async chat(messages: LLMMessage[], tools: LLMTool[], systemPrompt: string): Promise<LLMResponse> {
    // Filter out system messages — Anthropic uses a separate system param
    const filtered = messages.filter(m => m.role !== 'system');

    const anthropicTools: Anthropic.Tool[] = tools.map(t => ({
      name: t.name,
      description: t.description,
      input_schema: t.input_schema as Anthropic.Tool['input_schema'],
    }));

    const response = await this.client.messages.create({
      model: this.model,
      max_tokens: 4096,
      system: systemPrompt,
      tools: anthropicTools,
      messages: filtered as Anthropic.MessageParam[],
    });

    const textBlocks = response.content.filter((b): b is Anthropic.TextBlock => b.type === 'text');
    const toolBlocks = response.content.filter((b): b is Anthropic.ToolUseBlock => b.type === 'tool_use');

    const text = textBlocks.map(b => b.text).join('\n');

    if (response.stop_reason === 'tool_use') {
      return {
        text,
        stopReason: 'tool_use',
        toolCalls: toolBlocks.map(b => ({
          id: b.id,
          name: b.name,
          input: b.input as Record<string, unknown>,
        })),
      };
    }

    return { text, toolCalls: [], stopReason: 'end_turn' };
  }
}

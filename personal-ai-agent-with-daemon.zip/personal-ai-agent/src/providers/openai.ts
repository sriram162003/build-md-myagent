// src/providers/openai.ts
// OpenAI-compatible provider — works with OpenAI, Groq, LM Studio,
// Together AI, Mistral API, and any other OpenAI-compatible endpoint.

import type { LLMProvider, LLMMessage, LLMTool, LLMResponse } from './types.js';

const OPENAI_BASE_URL = process.env.OPENAI_BASE_URL || 'https://api.openai.com/v1';
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || '';
const OPENAI_MODEL = process.env.LLM_MODEL || 'gpt-4o';

interface OpenAIToolDef {
  type: 'function';
  function: {
    name: string;
    description: string;
    parameters: Record<string, unknown>;
  };
}

interface OpenAIMessage {
  role: string;
  content: string | null;
  tool_calls?: Array<{
    id: string;
    type: 'function';
    function: { name: string; arguments: string };
  }>;
  tool_call_id?: string;
}

export class OpenAIProvider implements LLMProvider {
  name = 'openai';

  async chat(messages: LLMMessage[], tools: LLMTool[], systemPrompt: string): Promise<LLMResponse> {
    const openaiTools: OpenAIToolDef[] = tools.map(t => ({
      type: 'function',
      function: {
        name: t.name,
        description: t.description,
        parameters: t.input_schema,
      },
    }));

    const msgs: OpenAIMessage[] = [
      { role: 'system', content: systemPrompt },
      ...messages.map(m => ({ role: m.role, content: m.content })),
    ];

    const body: Record<string, unknown> = {
      model: OPENAI_MODEL,
      messages: msgs,
      max_tokens: 4096,
    };

    if (tools.length > 0) {
      body.tools = openaiTools;
      body.tool_choice = 'auto';
    }

    const res = await fetch(`${OPENAI_BASE_URL}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(OPENAI_API_KEY ? { Authorization: `Bearer ${OPENAI_API_KEY}` } : {}),
      },
      body: JSON.stringify(body),
    });

    if (!res.ok) {
      throw new Error(`OpenAI API error: ${res.status} ${await res.text()}`);
    }

    const data = await res.json() as {
      choices: Array<{
        message: {
          content: string | null;
          tool_calls?: Array<{
            id: string;
            function: { name: string; arguments: string };
          }>;
        };
        finish_reason: string;
      }>;
    };

    const choice = data.choices[0];
    const msg = choice.message;

    if (choice.finish_reason === 'tool_calls' && msg.tool_calls?.length) {
      return {
        text: msg.content || '',
        stopReason: 'tool_use',
        toolCalls: msg.tool_calls.map(tc => ({
          id: tc.id,
          name: tc.function.name,
          input: JSON.parse(tc.function.arguments),
        })),
      };
    }

    return { text: msg.content || '', toolCalls: [], stopReason: 'end_turn' };
  }
}

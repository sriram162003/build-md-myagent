// src/providers/types.ts
// Shared types for all LLM providers

export interface LLMMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export interface LLMTool {
  name: string;
  description: string;
  input_schema: Record<string, unknown>;
}

export interface LLMToolCall {
  id: string;
  name: string;
  input: Record<string, unknown>;
}

export interface LLMResponse {
  text: string;
  toolCalls: LLMToolCall[];
  stopReason: 'end_turn' | 'tool_use' | 'error';
}

export interface LLMProvider {
  name: string;
  chat(messages: LLMMessage[], tools: LLMTool[], systemPrompt: string): Promise<LLMResponse>;
}

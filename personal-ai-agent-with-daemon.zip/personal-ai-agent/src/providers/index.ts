// src/providers/index.ts
// Factory — picks the right provider based on LLM_PROVIDER env var.

export type { LLMProvider, LLMMessage, LLMTool, LLMResponse, LLMToolCall } from './types.js';

import type { LLMProvider } from './types.js';

export type ProviderName = 'anthropic' | 'ollama' | 'openai';

let _provider: LLMProvider | null = null;

export async function initProvider(): Promise<LLMProvider> {
  if (_provider) return _provider;

  const name = (process.env.LLM_PROVIDER || 'anthropic').toLowerCase() as ProviderName;

  switch (name) {
    case 'anthropic': {
      const { AnthropicProvider } = await import('./anthropic.js');
      _provider = new AnthropicProvider();
      break;
    }
    case 'ollama': {
      const { OllamaProvider } = await import('./ollama.js');
      _provider = new OllamaProvider();
      break;
    }
    case 'openai': {
      const { OpenAIProvider } = await import('./openai.js');
      _provider = new OpenAIProvider();
      break;
    }
    default:
      throw new Error(`Unknown LLM_PROVIDER: "${name}". Valid options: anthropic, ollama, openai`);
  }

  console.log(`[Provider] Using: ${_provider!.name} (model: ${process.env.LLM_MODEL || 'default'})`);
  return _provider!;
}

export function getProvider(): LLMProvider {
  if (!_provider) throw new Error('Provider not initialized. Call initProvider() first.');
  return _provider;
}

// src/agent.ts
// The core AI agent — provider-agnostic agentic loop with tool calling.

import { getProvider, LLMMessage } from './providers/index.js';
import { sessionManager } from './session.js';
import { skillManager } from './skills/skillManager.js';
import { allSkillTools } from './skills/skillTools.js';
import { searchTool } from './tools/search.js';
import { codeExecTool } from './tools/codeExec.js';
import { saveFileTool, readFileTool, listFilesTool, deleteFileTool } from './tools/fileHandler.js';
import { ChannelName, IncomingMessage, AgentResponse, Tool, Message } from './types.js';

const BASE_SYSTEM_PROMPT = `You are a personal AI assistant — smart, capable, and always learning.
You have access to tools for web search, code execution, file management, and a self-growing skills system.

## Core Principles
- Be concise but thorough. Format with markdown when it helps clarity.
- When using tools, briefly explain what you're doing.
- Chain multiple tool calls as needed to fully complete tasks.
- When you solve a novel or complex problem, consider saving the approach as a skill.
- Before creating a skill, search_skills first to avoid duplicates.

## Self-Improvement
You can write your own skills using create_skill and update_skill.
Skills are persistent knowledge modules injected into future conversations.
Great skills capture: reusable workflows, discovered patterns, user preferences, domain expertise.

Current date: ${new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}`;

// All available tools
const TOOLS: Tool[] = [
  searchTool,
  codeExecTool,
  saveFileTool,
  readFileTool,
  listFilesTool,
  deleteFileTool,
  ...allSkillTools,
];

// Tool lookup map
const toolMap = new Map(TOOLS.map(t => [t.name, t]));

/** Build dynamic system prompt with current skill registry injected */
function buildSystemPrompt(): string {
  const skillContext = skillManager.buildSystemContext();
  return skillContext ? `${BASE_SYSTEM_PROMPT}\n${skillContext}` : BASE_SYSTEM_PROMPT;
}

/**
 * Convert our internal message history to a flat LLMMessage[] array.
 * Normalises Anthropic content blocks and plain strings to a common format.
 */
function toProviderMessages(messages: Message[]): LLMMessage[] {
  return messages
    .filter(m => m.role === 'user' || m.role === 'assistant')
    .map(m => ({
      role: m.role as 'user' | 'assistant',
      content: typeof m.content === 'string'
        ? m.content
        : (m.content as Array<{ type: string; text?: string }>)
            .filter(b => b.type === 'text')
            .map(b => b.text || '').join('\n'),
    }));
}

export async function processMessage(incoming: IncomingMessage): Promise<AgentResponse> {
  const { channel, userId, username, text } = incoming;
  const toolsUsed: string[] = [];

  const provider = getProvider();

  // Build user message, handle uploaded files
  let userContent = text;
  if (incoming.files && incoming.files.length > 0) {
    const fileNames = incoming.files.map(f => f.name).join(', ');
    userContent += `\n\n[Uploaded files: ${fileNames}]`;
    for (const file of incoming.files) {
      try {
        const content = file.data.toString('utf-8');
        await saveFileTool.execute({ filename: file.name, content });
        userContent += `\n(File "${file.name}" has been saved — you can reference it)`;
      } catch {
        userContent += `\n(Note: "${file.name}" could not be auto-saved as text)`;
      }
    }
  }

  // Append user message to session
  const userMessage: Message = { role: 'user', content: userContent };
  sessionManager.addMessage(channel, userId, userMessage);

  console.log(`[Agent] ${channel}/${username || userId} via ${provider.name}: "${text.slice(0, 60)}..."`);

  const llmTools = TOOLS.map(t => ({
    name: t.name,
    description: t.description,
    input_schema: t.input_schema,
  }));

  // Agentic loop — keep calling the LLM until it stops requesting tools
  let finalText = '';
  const turnMessages: LLMMessage[] = toProviderMessages(sessionManager.getMessages(channel, userId));

  for (let iteration = 0; iteration < 10; iteration++) {
    const response = await provider.chat(turnMessages, llmTools, buildSystemPrompt());

    if (response.text) {
      finalText = response.text;
    }

    if (response.stopReason === 'end_turn' || response.toolCalls.length === 0) {
      break;
    }

    // Add assistant thinking to turn context
    if (response.text) {
      turnMessages.push({ role: 'assistant', content: response.text });
    }

    // Execute tool calls sequentially and inject results
    for (const toolCall of response.toolCalls) {
      const tool = toolMap.get(toolCall.name);
      toolsUsed.push(toolCall.name);
      console.log(`[Agent] Tool call: ${toolCall.name}`, toolCall.input);

      let result: string;
      if (!tool) {
        result = `Error: Unknown tool "${toolCall.name}"`;
      } else {
        try {
          result = await tool.execute(toolCall.input);
        } catch (err) {
          result = `Tool error: ${err instanceof Error ? err.message : String(err)}`;
        }
      }

      // Inject tool result as user message (works universally across all providers)
      turnMessages.push({
        role: 'user',
        content: `[Tool result for ${toolCall.name}]\n${result}`,
      });
    }
  }

  // Persist the final assistant response to the session
  sessionManager.addMessage(channel, userId, {
    role: 'assistant',
    content: finalText || "I'm sorry, I wasn't able to generate a response.",
  });

  return {
    text: finalText || "I'm sorry, I wasn't able to generate a response.",
    toolsUsed,
  };
}

export function resetSession(channel: ChannelName, userId: string): void {
  sessionManager.reset(channel, userId);
}

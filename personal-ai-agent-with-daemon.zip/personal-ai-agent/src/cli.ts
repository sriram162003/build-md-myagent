#!/usr/bin/env node
// src/cli.ts
// Built-in CLI — onboard, daemon install/start/stop/status/logs
// Usage: node dist/cli.js [command] [flags]

import fs from 'fs';
import path from 'path';
import os from 'os';
import { execSync, spawn, spawnSync } from 'child_process';
import readline from 'readline';

// ─── Paths ────────────────────────────────────────────────────────────────────

const HOME_DIR   = path.resolve(process.env.AGENT_HOME || path.join(os.homedir(), '.personal-agent'));
const ENV_FILE   = path.join(HOME_DIR, '.env');
const PID_FILE   = path.join(HOME_DIR, 'agent.pid');
const LOG_FILE   = path.join(HOME_DIR, 'agent.log');
const SVC_FILE   = path.join(HOME_DIR, 'agent.service');   // systemd unit path (copy)
const ENTRY      = path.resolve(path.join(path.dirname(new URL(import.meta.url).pathname), 'index.js'));

fs.mkdirSync(HOME_DIR, { recursive: true });

// ─── Colours ──────────────────────────────────────────────────────────────────

const c = {
  reset:  '\x1b[0m',
  bold:   '\x1b[1m',
  dim:    '\x1b[2m',
  green:  '\x1b[32m',
  yellow: '\x1b[33m',
  red:    '\x1b[31m',
  cyan:   '\x1b[36m',
  blue:   '\x1b[34m',
};

const ok   = (s: string) => console.log(`${c.green}✔${c.reset}  ${s}`);
const warn = (s: string) => console.log(`${c.yellow}⚠${c.reset}  ${s}`);
const err  = (s: string) => console.log(`${c.red}✖${c.reset}  ${s}`);
const info = (s: string) => console.log(`${c.cyan}›${c.reset}  ${s}`);
const hdr  = (s: string) => console.log(`\n${c.bold}${c.blue}${s}${c.reset}`);
const sep  = ()           => console.log(`${c.dim}${'─'.repeat(50)}${c.reset}`);

// ─── Helpers ──────────────────────────────────────────────────────────────────

function ask(question: string, fallback = ''): Promise<string> {
  return new Promise(resolve => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    const prompt = fallback
      ? `${c.cyan}?${c.reset} ${question} ${c.dim}[${fallback}]${c.reset}: `
      : `${c.cyan}?${c.reset} ${question}: `;
    rl.question(prompt, answer => {
      rl.close();
      resolve(answer.trim() || fallback);
    });
  });
}

function askSecret(question: string): Promise<string> {
  return new Promise(resolve => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    process.stdout.write(`${c.cyan}?${c.reset} ${question}: `);
    // hide input
    if (process.stdin.isTTY) process.stdin.setRawMode(true);
    let input = '';
    process.stdin.resume();
    process.stdin.setEncoding('utf8');
    const onData = (ch: string) => {
      if (ch === '\n' || ch === '\r' || ch === '\u0004') {
        if (process.stdin.isTTY) process.stdin.setRawMode(false);
        process.stdin.pause();
        process.stdin.removeListener('data', onData);
        console.log('');
        rl.close();
        resolve(input);
      } else if (ch === '\u0003') {
        process.exit();
      } else if (ch === '\u007f') {
        input = input.slice(0, -1);
      } else {
        input += ch;
        process.stdout.write('*');
      }
    };
    process.stdin.on('data', onData);
  });
}

function readEnv(): Record<string, string> {
  if (!fs.existsSync(ENV_FILE)) return {};
  const lines = fs.readFileSync(ENV_FILE, 'utf-8').split('\n');
  const env: Record<string, string> = {};
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const idx = trimmed.indexOf('=');
    if (idx === -1) continue;
    const key = trimmed.slice(0, idx).trim();
    const val = trimmed.slice(idx + 1).trim().replace(/^["']|["']$/g, '');
    env[key] = val;
  }
  return env;
}

function writeEnv(vars: Record<string, string>): void {
  const existing = readEnv();
  const merged = { ...existing, ...vars };
  const lines = Object.entries(merged)
    .filter(([, v]) => v !== '')
    .map(([k, v]) => `${k}=${v}`);
  fs.writeFileSync(ENV_FILE, lines.join('\n') + '\n');
}

function getPid(): number | null {
  if (!fs.existsSync(PID_FILE)) return null;
  const pid = parseInt(fs.readFileSync(PID_FILE, 'utf-8').trim(), 10);
  if (isNaN(pid)) return null;
  // check if process is alive
  try { process.kill(pid, 0); return pid; } catch { return null; }
}

function isSystemd(): boolean {
  try { execSync('systemctl --version', { stdio: 'ignore' }); return true; } catch { return false; }
}

function nodeExec(): string {
  return process.execPath;
}

// ─── ONBOARD ──────────────────────────────────────────────────────────────────

async function cmdOnboard(installDaemon: boolean) {
  console.log(`\n${c.bold}${c.cyan}╔══════════════════════════════════════╗${c.reset}`);
  console.log(`${c.bold}${c.cyan}║     Personal AI Agent — Onboarding   ║${c.reset}`);
  console.log(`${c.bold}${c.cyan}╚══════════════════════════════════════╝${c.reset}\n`);
  info(`Config will be saved to: ${c.dim}${ENV_FILE}${c.reset}`);

  const existing = readEnv();

  // ── LLM Provider ──
  hdr('Step 1 — LLM Provider');
  sep();
  info('Choose your AI provider:');
  console.log(`  ${c.bold}1${c.reset}  Anthropic Claude  (needs API key)`);
  console.log(`  ${c.bold}2${c.reset}  Ollama            (local, free, needs ollama running)`);
  console.log(`  ${c.bold}3${c.reset}  OpenAI / Compatible (GPT, Groq, LM Studio, Mistral...)`);

  const provChoice = await ask('Provider', existing.LLM_PROVIDER === 'ollama' ? '2' : existing.LLM_PROVIDER === 'openai' ? '3' : '1');
  const providerMap: Record<string, string> = { '1': 'anthropic', '2': 'ollama', '3': 'openai' };
  const provider = providerMap[provChoice] || provChoice;

  const envVars: Record<string, string> = { LLM_PROVIDER: provider };

  if (provider === 'anthropic') {
    const key = await askSecret('Anthropic API key');
    if (!key) { err('API key required for Anthropic. Aborting.'); process.exit(1); }
    envVars['ANTHROPIC_API_KEY'] = key;
    const model = await ask('Model', existing.LLM_MODEL || 'claude-opus-4-6');
    envVars['LLM_MODEL'] = model;
  } else if (provider === 'ollama') {
    const base = await ask('Ollama URL', existing.OLLAMA_BASE_URL || 'http://localhost:11434');
    envVars['OLLAMA_BASE_URL'] = base;
    const model = await ask('Model (e.g. llama3.2, mistral, qwen2.5)', existing.LLM_MODEL || 'llama3.2');
    envVars['LLM_MODEL'] = model;
    info(`Make sure you've pulled the model: ${c.dim}ollama pull ${model}${c.reset}`);
  } else if (provider === 'openai') {
    const key = await askSecret('OpenAI API key (leave blank for local/custom endpoint)');
    if (key) envVars['OPENAI_API_KEY'] = key;
    const baseUrl = await ask('Base URL (leave blank for OpenAI)', existing.OPENAI_BASE_URL || '');
    if (baseUrl) envVars['OPENAI_BASE_URL'] = baseUrl;
    const model = await ask('Model', existing.LLM_MODEL || 'gpt-4o');
    envVars['LLM_MODEL'] = model;
  }

  // ── Gateway ──
  hdr('Step 2 — Gateway');
  sep();
  const port = await ask('Port', existing.PORT || '3000');
  envVars['PORT'] = port;

  // ── Optional: Brave Search ──
  hdr('Step 3 — Web Search (optional)');
  sep();
  info('Get a free Brave Search API key at https://brave.com/search/api (2000 queries/month free)');
  const braveKey = await ask('Brave API key (leave blank to skip)', existing.BRAVE_API_KEY || '');
  if (braveKey) envVars['BRAVE_API_KEY'] = braveKey;

  // ── Optional channels ──
  hdr('Step 4 — Channels (all optional, WebChat always works)');
  sep();
  const telegramToken = await ask('Telegram bot token (leave blank to skip)', existing.TELEGRAM_BOT_TOKEN || '');
  if (telegramToken) envVars['TELEGRAM_BOT_TOKEN'] = telegramToken;
  const discordToken = await ask('Discord bot token (leave blank to skip)', existing.DISCORD_BOT_TOKEN || '');
  if (discordToken) envVars['DISCORD_BOT_TOKEN'] = discordToken;

  // ── Save config ──
  writeEnv(envVars);
  ok(`Config saved to ${ENV_FILE}`);

  // ── Daemon install ──
  if (installDaemon || (await ask('\nInstall as background daemon (auto-start on login)?', 'y')).toLowerCase() === 'y') {
    await cmdInstallDaemon();
  } else {
    hdr('Done!');
    info(`Start manually:      ${c.bold}npm run dev${c.reset}  (or ${c.bold}npm start${c.reset} after build)`);
    info(`Or use the CLI:      ${c.bold}node dist/cli.js start${c.reset}`);
    info(`WebChat UI:          ${c.bold}http://localhost:${envVars['PORT'] || 3000}${c.reset}`);
  }
}

// ─── DAEMON INSTALL ───────────────────────────────────────────────────────────

async function cmdInstallDaemon() {
  hdr('Installing daemon…');

  const envFileArg = `AGENT_HOME=${HOME_DIR}`;

  if (isSystemd()) {
    // ── systemd (Linux / WSL2 with systemd enabled) ──
    const unitName = 'personal-agent';
    const unitContent = `[Unit]
Description=Personal AI Agent
After=network.target

[Service]
Type=simple
ExecStart=${nodeExec()} ${ENTRY}
WorkingDirectory=${path.dirname(ENTRY)}
EnvironmentFile=${ENV_FILE}
Environment="${envFileArg}"
Restart=on-failure
RestartSec=5s
StandardOutput=append:${LOG_FILE}
StandardError=append:${LOG_FILE}

[Install]
WantedBy=default.target
`;
    const unitDest = `/etc/systemd/system/${unitName}.service`;
    const tmpUnit = path.join(HOME_DIR, `${unitName}.service`);
    fs.writeFileSync(tmpUnit, unitContent);

    // try user systemd first (no sudo), fall back to system (sudo)
    const userUnitDir = path.join(os.homedir(), '.config', 'systemd', 'user');
    const userUnitDest = path.join(userUnitDir, `${unitName}.service`);

    try {
      fs.mkdirSync(userUnitDir, { recursive: true });
      fs.copyFileSync(tmpUnit, userUnitDest);
      execSync(`systemctl --user daemon-reload`);
      execSync(`systemctl --user enable ${unitName}`);
      execSync(`systemctl --user start ${unitName}`);
      ok(`systemd user service installed: ${userUnitDest}`);
      ok(`Daemon started via systemd --user`);
      info(`Manage with: ${c.dim}systemctl --user {start|stop|restart|status} ${unitName}${c.reset}`);
    } catch {
      warn('User systemd failed — trying system-level (may need sudo)');
      try {
        execSync(`sudo cp ${tmpUnit} ${unitDest}`);
        execSync(`sudo systemctl daemon-reload`);
        execSync(`sudo systemctl enable ${unitName}`);
        execSync(`sudo systemctl start ${unitName}`);
        ok(`systemd system service installed: ${unitDest}`);
        ok(`Daemon started via systemd`);
        info(`Manage with: ${c.dim}sudo systemctl {start|stop|restart|status} ${unitName}${c.reset}`);
      } catch (e) {
        warn(`systemd install failed. Falling back to background process mode.`);
        await cmdStart();
      }
    }
  } else {
    // ── No systemd — write a shell-based autostart via ~/.bashrc / ~/.profile ──
    warn('systemd not available — using nohup background process + ~/.profile autostart');
    await cmdStart();

    // Add autostart to .profile if not already there
    const profileFile = path.join(os.homedir(), '.profile');
    const autoStartLine = `\n# Personal AI Agent autostart\n[ -f "${PID_FILE}" ] || ${nodeExec()} ${ENTRY} --env ${ENV_FILE} >> ${LOG_FILE} 2>&1 &\n`;
    const profileContent = fs.existsSync(profileFile) ? fs.readFileSync(profileFile, 'utf-8') : '';
    if (!profileContent.includes('Personal AI Agent autostart')) {
      fs.appendFileSync(profileFile, autoStartLine);
      ok(`Autostart added to ${profileFile}`);
    } else {
      info('Autostart entry already in ~/.profile');
    }
  }

  hdr('Daemon installed ✨');
  sep();
  info(`Logs:    ${c.dim}node dist/cli.js logs${c.reset}`);
  info(`Status:  ${c.dim}node dist/cli.js status${c.reset}`);
  info(`Stop:    ${c.dim}node dist/cli.js stop${c.reset}`);
  info(`WebChat: ${c.bold}http://localhost:${readEnv()['PORT'] || 3000}${c.reset}`);
}

// ─── START ────────────────────────────────────────────────────────────────────

async function cmdStart() {
  if (getPid()) {
    warn('Agent is already running. Use `status` to check or `restart` to restart.');
    return;
  }

  // Load env
  if (fs.existsSync(ENV_FILE)) {
    const vars = readEnv();
    for (const [k, v] of Object.entries(vars)) {
      process.env[k] = process.env[k] ?? v;
    }
  }

  info('Starting agent in background…');
  const logStream = fs.openSync(LOG_FILE, 'a');
  const child = spawn(nodeExec(), [ENTRY], {
    detached: true,
    stdio: ['ignore', logStream, logStream],
    env: { ...process.env, AGENT_HOME: HOME_DIR },
  });
  child.unref();

  if (child.pid) {
    fs.writeFileSync(PID_FILE, String(child.pid));
    ok(`Agent started  (PID ${child.pid})`);
    info(`Logs:    ${c.dim}node dist/cli.js logs${c.reset}`);
    info(`WebChat: ${c.bold}http://localhost:${process.env.PORT || 3000}${c.reset}`);
  } else {
    err('Failed to start agent.');
  }
}

// ─── STOP ─────────────────────────────────────────────────────────────────────

function cmdStop() {
  const pid = getPid();
  if (!pid) { warn('Agent is not running.'); return; }
  try {
    process.kill(pid, 'SIGTERM');
    fs.unlinkSync(PID_FILE);
    ok(`Agent stopped (PID ${pid})`);
  } catch (e) {
    err(`Failed to stop: ${e}`);
  }
}

// ─── RESTART ──────────────────────────────────────────────────────────────────

async function cmdRestart() {
  cmdStop();
  await new Promise(r => setTimeout(r, 1000));
  await cmdStart();
}

// ─── STATUS ───────────────────────────────────────────────────────────────────

function cmdStatus() {
  hdr('Agent Status');
  sep();

  const pid = getPid();
  if (pid) {
    ok(`Running  (PID ${pid})`);
  } else {
    err('Not running');
  }

  const env = readEnv();
  info(`Provider:  ${c.bold}${env.LLM_PROVIDER || 'anthropic'}${c.reset}`);
  info(`Model:     ${c.bold}${env.LLM_MODEL || 'default'}${c.reset}`);
  info(`WebChat:   ${c.bold}http://localhost:${env.PORT || 3000}${c.reset}`);
  info(`Config:    ${c.dim}${ENV_FILE}${c.reset}`);
  info(`Logs:      ${c.dim}${LOG_FILE}${c.reset}`);

  // Show systemd status if available
  if (isSystemd()) {
    try {
      const out = execSync('systemctl --user is-active personal-agent 2>/dev/null', { encoding: 'utf-8' }).trim();
      info(`systemd:   ${out === 'active' ? c.green : c.yellow}${out}${c.reset}`);
    } catch { /* not installed as service */ }
  }

  // show last 5 log lines
  if (fs.existsSync(LOG_FILE)) {
    sep();
    console.log(`${c.dim}Last 5 log lines:${c.reset}`);
    try {
      const lines = fs.readFileSync(LOG_FILE, 'utf-8').trim().split('\n').slice(-5);
      lines.forEach(l => console.log(`  ${c.dim}${l}${c.reset}`));
    } catch { /* */ }
  }
  sep();
}

// ─── LOGS ─────────────────────────────────────────────────────────────────────

function cmdLogs(follow: boolean) {
  if (!fs.existsSync(LOG_FILE)) { warn('No log file yet. Start the agent first.'); return; }

  if (follow) {
    info(`Tailing ${LOG_FILE} (Ctrl+C to stop)\n`);
    const tail = spawn('tail', ['-f', LOG_FILE], { stdio: 'inherit' });
    tail.on('close', () => {});
  } else {
    const content = fs.readFileSync(LOG_FILE, 'utf-8');
    const lines = content.trim().split('\n').slice(-50);
    lines.forEach(l => console.log(l));
  }
}

// ─── DOCTOR ───────────────────────────────────────────────────────────────────

function cmdDoctor() {
  hdr('Doctor — checking config');
  sep();

  const env = readEnv();
  let issues = 0;

  const check = (label: string, pass: boolean, fix?: string) => {
    if (pass) { ok(label); } else { err(label); if (fix) info(`  Fix: ${fix}`); issues++; }
  };

  check('Config file exists', fs.existsSync(ENV_FILE), `Run: node dist/cli.js onboard`);

  const provider = env.LLM_PROVIDER || 'anthropic';
  check(`LLM_PROVIDER set (${provider})`, !!provider);

  if (provider === 'anthropic') {
    check('ANTHROPIC_API_KEY set', !!env.ANTHROPIC_API_KEY, 'Add ANTHROPIC_API_KEY to your .env or re-run onboard');
  } else if (provider === 'ollama') {
    check('OLLAMA_BASE_URL set', !!env.OLLAMA_BASE_URL);
    // test connection
    try {
      const result = spawnSync('curl', ['-s', '--max-time', '2', `${env.OLLAMA_BASE_URL || 'http://localhost:11434'}/api/tags`], { encoding: 'utf-8' });
      check('Ollama reachable', result.status === 0, `Make sure Ollama is running: ollama serve`);
    } catch { check('Ollama reachable', false, 'Run: ollama serve'); }
  } else if (provider === 'openai') {
    check('OPENAI_API_KEY or OPENAI_BASE_URL set', !!(env.OPENAI_API_KEY || env.OPENAI_BASE_URL));
  }

  check('PORT set', !!env.PORT);
  check('Node version >= 18', parseInt(process.versions.node.split('.')[0]) >= 18,
    'Upgrade Node.js: nvm install 20 && nvm use 20');

  if (isSystemd()) {
    try {
      const out = execSync('systemctl --user is-active personal-agent 2>/dev/null', { encoding: 'utf-8' }).trim();
      check('systemd service active', out === 'active', 'Run: node dist/cli.js daemon install');
    } catch { info('systemd service not installed (optional)'); }
  }

  sep();
  if (issues === 0) { ok('All checks passed!'); } else { warn(`${issues} issue(s) found.`); }
}

// ─── HELP ─────────────────────────────────────────────────────────────────────

function cmdHelp() {
  console.log(`
${c.bold}${c.cyan}Personal AI Agent CLI${c.reset}

${c.bold}Usage:${c.reset}
  node dist/cli.js <command> [options]

${c.bold}Commands:${c.reset}
  ${c.green}onboard${c.reset}                  Interactive setup wizard
  ${c.green}onboard --install-daemon${c.reset} Setup + install as background service
  ${c.green}start${c.reset}                    Start the agent in the background
  ${c.green}stop${c.reset}                     Stop the running agent
  ${c.green}restart${c.reset}                  Restart the agent
  ${c.green}status${c.reset}                   Show running status + config summary
  ${c.green}logs${c.reset}                     Show last 50 log lines
  ${c.green}logs --follow${c.reset}            Tail logs live (Ctrl+C to exit)
  ${c.green}daemon install${c.reset}           Install as systemd service (auto-start on login)
  ${c.green}doctor${c.reset}                   Check config and connectivity
  ${c.green}help${c.reset}                     Show this help

${c.bold}Examples:${c.reset}
  node dist/cli.js onboard --install-daemon
  node dist/cli.js status
  node dist/cli.js logs --follow
  node dist/cli.js restart

${c.bold}Config location:${c.reset}  ${c.dim}${ENV_FILE}${c.reset}
${c.bold}Logs location:${c.reset}    ${c.dim}${LOG_FILE}${c.reset}
`);
}

// ─── Router ───────────────────────────────────────────────────────────────────

const [,, cmd, ...rest] = process.argv;

switch (cmd) {
  case 'onboard':
    await cmdOnboard(rest.includes('--install-daemon'));
    break;
  case 'start':
    await cmdStart();
    break;
  case 'stop':
    cmdStop();
    break;
  case 'restart':
    await cmdRestart();
    break;
  case 'status':
    cmdStatus();
    break;
  case 'logs':
    cmdLogs(rest.includes('--follow') || rest.includes('-f'));
    break;
  case 'daemon':
    if (rest[0] === 'install') await cmdInstallDaemon();
    else { err(`Unknown daemon subcommand: ${rest[0]}`); cmdHelp(); }
    break;
  case 'doctor':
    cmdDoctor();
    break;
  case 'help':
  case '--help':
  case '-h':
  case undefined:
    cmdHelp();
    break;
  default:
    err(`Unknown command: ${cmd}`);
    cmdHelp();
    process.exit(1);
}

// src/gateway.ts
// Main Express gateway — serves WebChat UI, WebSocket, and health endpoint.

import express from 'express';
import { createServer } from 'http';
import { WebSocketServer } from 'ws';
import path from 'path';
import multer from 'multer';
import { fileURLToPath } from 'url';
import { createWebChatAdapter } from './channels/webchat.js';
import { sessionManager } from './session.js';
import { skillManager } from './skills/skillManager.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = parseInt(process.env.PORT || '3000');
const MAX_FILE_SIZE = parseInt(process.env.MAX_FILE_SIZE_MB || '10') * 1024 * 1024;

export async function startGateway() {
  const app = express();
  const server = createServer(app);
  const wss = new WebSocketServer({ server, path: '/ws' });

  // Middleware
  app.use(express.json({ limit: '50mb' }));
  app.use(express.static(path.join(__dirname, '..', 'public')));

  const upload = multer({
    storage: multer.memoryStorage(),
    limits: { fileSize: MAX_FILE_SIZE },
  });

  // ── Routes ──────────────────────────────────────────────────────────────────

  // Health check
  app.get('/health', (_req, res) => {
    const stats = sessionManager.getStats();
    res.json({
      status: 'ok',
      uptime: Math.floor(process.uptime()),
      sessions: stats,
      model: process.env.CLAUDE_MODEL || 'claude-opus-4-6',
      channels: {
        telegram: !!process.env.TELEGRAM_BOT_TOKEN,
        discord: !!process.env.DISCORD_BOT_TOKEN,
        slack: !!(process.env.SLACK_BOT_TOKEN && process.env.SLACK_APP_TOKEN),
        webchat: true,
      },
    });
  });

  // Sessions API
  app.get('/api/sessions', (_req, res) => {
    const sessions = sessionManager.listAll().map(s => ({
      id: s.id,
      channel: s.channel,
      username: s.username,
      messageCount: s.messages.length,
      createdAt: s.createdAt,
      updatedAt: s.updatedAt,
    }));
    res.json(sessions);
  });

  // Skills API
  app.get("/api/skills", (_req, res) => {
    const skills = skillManager.list().map(s => ({
      name: s.frontmatter.name,
      description: s.frontmatter.description,
      version: s.frontmatter.version,
      enabled: s.frontmatter.enabled,
      tags: s.frontmatter.tags,
      author: s.frontmatter.author,
      updated: s.frontmatter.updated,
      bodyLength: s.body.length,
    }));
    res.json(skills);
  });

  app.get("/api/skills/:name", (req, res) => {
    const skill = skillManager.get(req.params.name);
    if (!skill) { res.status(404).json({ error: "Skill not found" }); return; }
    res.json(skill);
  });

  // WebChat
  app.get('/', (_req, res) => {
    res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
  });

  // Start WebChat WebSocket adapter
  const webchatAdapter = createWebChatAdapter(wss);
  await webchatAdapter.start();

  // Start HTTP server
  await new Promise<void>((resolve) => {
    server.listen(PORT, () => {
      console.log(`\n🚀 Gateway running at http://localhost:${PORT}`);
      console.log(`📊 Health: http://localhost:${PORT}/health`);
      console.log(`💬 WebChat: http://localhost:${PORT}/\n`);
      resolve();
    });
  });

  return { server, wss };
}

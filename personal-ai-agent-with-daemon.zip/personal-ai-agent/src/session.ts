// src/session.ts
// In-memory session store with optional JSON persistence.

import fs from 'fs';
import path from 'path';
import { Session, ChannelName, Message } from './types.js';

const SESSION_FILE = path.resolve(process.env.FILES_DIR || './agent-files', 'sessions.json');
const MAX_HISTORY = 50; // max messages per session before pruning

class SessionManager {
  private sessions: Map<string, Session> = new Map();

  constructor() {
    this.load();
  }

  /** Build a deterministic session ID from channel + userId */
  private buildId(channel: ChannelName, userId: string): string {
    return `${channel}:${userId}`;
  }

  /** Get or create a session */
  getOrCreate(channel: ChannelName, userId: string, username?: string): Session {
    const id = this.buildId(channel, userId);
    if (!this.sessions.has(id)) {
      const session: Session = {
        id,
        channel,
        userId,
        username,
        messages: [],
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      this.sessions.set(id, session);
    }
    const session = this.sessions.get(id)!;
    if (username) session.username = username;
    return session;
  }

  /** Append a message and prune if needed */
  addMessage(channel: ChannelName, userId: string, message: Message): void {
    const session = this.getOrCreate(channel, userId);
    session.messages.push(message);
    session.updatedAt = new Date();

    // Prune oldest messages if over limit, keeping pairs
    while (session.messages.length > MAX_HISTORY) {
      session.messages.shift();
    }

    this.save();
  }

  /** Get all messages for a session */
  getMessages(channel: ChannelName, userId: string): Message[] {
    return this.getOrCreate(channel, userId).messages;
  }

  /** Reset a session (clear history) */
  reset(channel: ChannelName, userId: string): void {
    const id = this.buildId(channel, userId);
    const existing = this.sessions.get(id);
    if (existing) {
      existing.messages = [];
      existing.updatedAt = new Date();
      this.save();
    }
  }

  /** List all active sessions */
  listAll(): Session[] {
    return Array.from(this.sessions.values());
  }

  /** Get session stats */
  getStats(): { total: number; byChannel: Record<string, number> } {
    const byChannel: Record<string, number> = {};
    for (const s of this.sessions.values()) {
      byChannel[s.channel] = (byChannel[s.channel] || 0) + 1;
    }
    return { total: this.sessions.size, byChannel };
  }

  /** Persist sessions to disk */
  private save(): void {
    try {
      const dir = path.dirname(SESSION_FILE);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
      const data = JSON.stringify(Array.from(this.sessions.entries()), null, 2);
      fs.writeFileSync(SESSION_FILE, data, 'utf-8');
    } catch {
      // Non-fatal: memory sessions still work
    }
  }

  /** Load sessions from disk on startup */
  private load(): void {
    try {
      if (fs.existsSync(SESSION_FILE)) {
        const data = JSON.parse(fs.readFileSync(SESSION_FILE, 'utf-8'));
        for (const [key, val] of data) {
          const session = val as Session;
          session.createdAt = new Date(session.createdAt);
          session.updatedAt = new Date(session.updatedAt);
          this.sessions.set(key, session);
        }
        console.log(`[Sessions] Loaded ${this.sessions.size} sessions from disk`);
      }
    } catch {
      // Start fresh if corrupted
    }
  }
}

export const sessionManager = new SessionManager();

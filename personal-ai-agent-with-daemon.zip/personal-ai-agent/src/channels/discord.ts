// src/channels/discord.ts

import {
  Client,
  GatewayIntentBits,
  Message,
  Events,
  ActivityType,
  AttachmentBuilder,
} from 'discord.js';
import { processMessage, resetSession } from '../agent.js';
import { ChannelAdapter } from '../types.js';
import axios from 'axios';

const ALLOWED_USERS = (process.env.DISCORD_ALLOWED_USERS || '')
  .split(',')
  .map(s => s.trim())
  .filter(Boolean);

function isAllowed(userId: string): boolean {
  if (ALLOWED_USERS.length === 0) return true;
  return ALLOWED_USERS.includes(userId);
}

async function downloadAttachment(url: string): Promise<Buffer> {
  const res = await axios.get(url, { responseType: 'arraybuffer', timeout: 30000 });
  return Buffer.from(res.data);
}

export function createDiscordAdapter(): ChannelAdapter {
  const token = process.env.DISCORD_BOT_TOKEN;
  if (!token) throw new Error('DISCORD_BOT_TOKEN not set');

  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.MessageContent,
      GatewayIntentBits.DirectMessages,
    ],
  });

  client.on(Events.ClientReady, (c) => {
    console.log(`[Discord] Bot ready: ${c.user.tag}`);
    c.user.setActivity('your questions', { type: ActivityType.Listening });
  });

  client.on(Events.MessageCreate, async (msg: Message) => {
    // Ignore bots
    if (msg.author.bot) return;

    // Only respond to DMs or when mentioned in guilds
    const isDM = !msg.guild;
    const isMentioned = msg.guild && msg.mentions.has(client.user!);
    if (!isDM && !isMentioned) return;

    const userId = msg.author.id;
    const username = msg.author.username;

    if (!isAllowed(userId)) {
      await msg.reply('⛔ You are not authorized to use this bot.');
      return;
    }

    // Strip bot mention from text
    let text = msg.content
      .replace(/<@!?\d+>/g, '')
      .trim();

    // Handle commands
    if (text.startsWith('!reset') || text.startsWith('!new')) {
      resetSession('discord', userId);
      await msg.reply('🔄 Session reset! Starting fresh.');
      return;
    }

    if (text.startsWith('!help')) {
      await msg.reply(
        '**Personal AI Assistant**\n\n' +
        'I can help with:\n' +
        '• 🔍 Web search\n• 💻 Run code\n• 📁 Save & read files\n• 💬 Conversation memory\n\n' +
        'Commands:\n`!reset` — Clear conversation\n`!help` — Show this message\n\n' +
        'DM me or @mention me in a channel!'
      );
      return;
    }

    // Download attachments
    const files = [];
    for (const [, att] of msg.attachments) {
      try {
        const data = await downloadAttachment(att.url);
        files.push({
          name: att.name || 'attachment',
          mimeType: att.contentType || 'application/octet-stream',
          data,
        });
        if (!text) text = `Process this file: ${att.name}`;
      } catch {
        await msg.reply('❌ Failed to download attachment.');
        return;
      }
    }

    if (!text && files.length === 0) {
      await msg.reply('Please send a message or attach a file!');
      return;
    }

    // Show typing indicator
    await msg.channel.sendTyping();

    try {
      const response = await processMessage({
        sessionId: `discord:${userId}`,
        channel: 'discord',
        userId,
        username,
        text,
        files,
      });

      // Discord has 2000 char limit per message
      const chunks = splitMessage(response.text);
      for (const chunk of chunks) {
        await msg.reply(chunk);
      }

    } catch (err) {
      const errMsg = err instanceof Error ? err.message : 'Unknown error';
      await msg.reply(`❌ Error: ${errMsg}`);
    }
  });

  return {
    name: 'discord',
    async start() {
      await client.login(token);
    },
    async stop() {
      client.destroy();
    },
    async send(userId: string, text: string) {
      const user = await client.users.fetch(userId);
      const dm = await user.createDM();
      const chunks = splitMessage(text);
      for (const chunk of chunks) {
        await dm.send(chunk);
      }
    },
  };
}

function splitMessage(text: string, maxLen = 1900): string[] {
  if (text.length <= maxLen) return [text];
  const chunks: string[] = [];
  let remaining = text;
  while (remaining.length > maxLen) {
    let idx = remaining.lastIndexOf('\n', maxLen);
    if (idx < 0) idx = maxLen;
    chunks.push(remaining.slice(0, idx));
    remaining = remaining.slice(idx).trimStart();
  }
  if (remaining) chunks.push(remaining);
  return chunks;
}

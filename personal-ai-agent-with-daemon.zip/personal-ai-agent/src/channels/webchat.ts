// src/channels/webchat.ts

import { WebSocketServer, WebSocket } from 'ws';
import { IncomingMessage } from 'http';
import { processMessage, resetSession } from '../agent.js';
import { ChannelAdapter } from '../types.js';

interface WSClient {
  ws: WebSocket;
  userId: string;
}

const clients = new Map<string, WSClient>();

export function createWebChatAdapter(wss: WebSocketServer): ChannelAdapter {
  wss.on('connection', (ws: WebSocket, req: IncomingMessage) => {
    // Generate a session ID for this browser session
    const userId = `web_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    clients.set(userId, { ws, userId });

    console.log(`[WebChat] New connection: ${userId}`);

    // Send welcome
    send(ws, { type: 'connected', userId, message: 'Connected to AI Agent' });

    ws.on('message', async (raw) => {
      let data: { type?: string; text?: string; reset?: boolean };
      try {
        data = JSON.parse(raw.toString());
      } catch {
        send(ws, { type: 'error', message: 'Invalid JSON' });
        return;
      }

      if (data.type === 'reset' || data.reset) {
        resetSession('webchat', userId);
        send(ws, { type: 'reset', message: 'Session cleared' });
        return;
      }

      if (data.type !== 'message' || !data.text?.trim()) return;

      send(ws, { type: 'typing', status: true });

      try {
        const response = await processMessage({
          sessionId: `webchat:${userId}`,
          channel: 'webchat',
          userId,
          text: data.text,
        });

        send(ws, {
          type: 'message',
          role: 'assistant',
          text: response.text,
          toolsUsed: response.toolsUsed,
          timestamp: new Date().toISOString(),
        });
      } catch (err) {
        const errMsg = err instanceof Error ? err.message : 'Unknown error';
        send(ws, { type: 'error', message: errMsg });
      } finally {
        send(ws, { type: 'typing', status: false });
      }
    });

    ws.on('close', () => {
      clients.delete(userId);
      console.log(`[WebChat] Disconnected: ${userId}`);
    });
  });

  function send(ws: WebSocket, data: object) {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(data));
    }
  }

  return {
    name: 'webchat',
    async start() {
      console.log('[WebChat] WebSocket server ready');
    },
    async stop() {
      wss.close();
    },
    async send(userId: string, text: string) {
      const client = clients.get(userId);
      if (client) {
        send(client.ws, { type: 'message', role: 'assistant', text });
      }
    },
  };
}

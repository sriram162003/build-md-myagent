// src/channels/telegram.ts

import { Telegraf, Context } from 'telegraf';
import { processMessage, resetSession } from '../agent.js';
import { ChannelAdapter } from '../types.js';
import axios from 'axios';

const ALLOWED_USERS = (process.env.TELEGRAM_ALLOWED_USERS || '')
  .split(',')
  .map(s => s.trim())
  .filter(Boolean);

function isAllowed(userId: string): boolean {
  if (ALLOWED_USERS.length === 0) return true;
  return ALLOWED_USERS.includes(userId);
}

async function downloadFile(url: string): Promise<Buffer> {
  const res = await axios.get(url, { responseType: 'arraybuffer', timeout: 30000 });
  return Buffer.from(res.data);
}

export function createTelegramAdapter(): ChannelAdapter {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) throw new Error('TELEGRAM_BOT_TOKEN not set');

  const bot = new Telegraf(token);

  async function handleMessage(ctx: Context) {
    const userId = String(ctx.from?.id || 'unknown');
    const username = ctx.from?.username || ctx.from?.first_name || userId;

    if (!isAllowed(userId)) {
      await ctx.reply('⛔ You are not authorized to use this bot.');
      return;
    }

    const message = ctx.message as { text?: string; document?: { file_id: string; file_name?: string; mime_type?: string }; photo?: Array<{ file_id: string }>; caption?: string; voice?: { file_id: string } };

    let text = message?.text || message?.caption || '';
    const files = [];

    // Handle /reset command
    if (text.startsWith('/reset') || text.startsWith('/new')) {
      resetSession('telegram', userId);
      await ctx.reply('🔄 Session reset! Starting fresh.');
      return;
    }

    // Handle /help command
    if (text.startsWith('/help') || text.startsWith('/start')) {
      await ctx.reply(
        `🤖 *Personal AI Assistant*\n\n` +
        `I can help you with:\n` +
        `• 🔍 Web search\n• 💻 Run code\n• 📁 Save & read files\n• 💬 Conversation memory\n\n` +
        `Commands:\n/reset — Clear conversation\n/help — Show this message\n\n` +
        `Send me any message to get started!`,
        { parse_mode: 'Markdown' }
      );
      return;
    }

    // Handle document uploads
    if (message?.document) {
      try {
        const fileLink = await ctx.telegram.getFileLink(message.document.file_id);
        const data = await downloadFile(fileLink.href);
        files.push({
          name: message.document.file_name || 'upload',
          mimeType: message.document.mime_type || 'application/octet-stream',
          data,
        });
        if (!text) text = `Process this file: ${message.document.file_name}`;
      } catch {
        await ctx.reply('❌ Failed to download the file.');
        return;
      }
    }

    // Handle photos
    if (message?.photo) {
      const photo = message.photo[message.photo.length - 1];
      try {
        const fileLink = await ctx.telegram.getFileLink(photo.file_id);
        const data = await downloadFile(fileLink.href);
        files.push({ name: 'photo.jpg', mimeType: 'image/jpeg', data });
        if (!text) text = 'What do you see in this image?';
      } catch {
        await ctx.reply('❌ Failed to download the photo.');
        return;
      }
    }

    if (!text && files.length === 0) {
      await ctx.reply('Please send a text message or file.');
      return;
    }

    // Show typing indicator
    await ctx.sendChatAction('typing');

    try {
      const response = await processMessage({
        sessionId: `telegram:${userId}`,
        channel: 'telegram',
        userId,
        username,
        text,
        files,
      });

      // Split long messages (Telegram has 4096 char limit)
      const chunks = splitMessage(response.text);
      for (const chunk of chunks) {
        await ctx.reply(chunk, { parse_mode: 'Markdown' });
      }

      if (response.toolsUsed.length > 0) {
        console.log(`[Telegram] Tools used: ${response.toolsUsed.join(', ')}`);
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unknown error';
      await ctx.reply(`❌ Error: ${msg}`);
    }
  }

  bot.on('message', handleMessage);

  return {
    name: 'telegram',
    async start() {
      await bot.launch();
      const me = await bot.telegram.getMe();
      console.log(`[Telegram] Bot started: @${me.username}`);
    },
    async stop() {
      bot.stop('SIGTERM');
    },
    async send(userId: string, text: string) {
      const chunks = splitMessage(text);
      for (const chunk of chunks) {
        await bot.telegram.sendMessage(userId, chunk, { parse_mode: 'Markdown' });
      }
    },
  };
}

function splitMessage(text: string, maxLen = 4000): string[] {
  if (text.length <= maxLen) return [text];
  const chunks: string[] = [];
  let remaining = text;
  while (remaining.length > maxLen) {
    let idx = remaining.lastIndexOf('\n', maxLen);
    if (idx < 0) idx = maxLen;
    chunks.push(remaining.slice(0, idx));
    remaining = remaining.slice(idx).trimStart();
  }
  if (remaining) chunks.push(remaining);
  return chunks;
}

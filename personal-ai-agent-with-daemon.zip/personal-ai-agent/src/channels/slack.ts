// src/channels/slack.ts

import { App, ReceiverEvent } from '@slack/bolt';
import { processMessage, resetSession } from '../agent.js';
import { ChannelAdapter } from '../types.js';
import axios from 'axios';

async function downloadFile(url: string, token: string): Promise<Buffer> {
  const res = await axios.get(url, {
    headers: { Authorization: `Bearer ${token}` },
    responseType: 'arraybuffer',
    timeout: 30000,
  });
  return Buffer.from(res.data);
}

export function createSlackAdapter(): ChannelAdapter {
  const botToken = process.env.SLACK_BOT_TOKEN;
  const appToken = process.env.SLACK_APP_TOKEN;
  const signingSecret = process.env.SLACK_SIGNING_SECRET;

  if (!botToken || !appToken || !signingSecret) {
    throw new Error('SLACK_BOT_TOKEN, SLACK_APP_TOKEN, and SLACK_SIGNING_SECRET must be set');
  }

  const app = new App({
    token: botToken,
    appToken,
    signingSecret,
    socketMode: true, // Use Socket Mode (no public URL needed)
  });

  // Handle DMs
  app.message(async ({ message, say, client }) => {
    const msg = message as { user?: string; text?: string; subtype?: string; files?: Array<{ url_private: string; name?: string; mimetype?: string }> };

    // Ignore bot messages and subtypes (edits, deletions)
    if (msg.subtype || !msg.user) return;

    const userId = msg.user;
    let text = msg.text || '';

    // Handle commands
    if (text.trim() === '!reset' || text.trim() === '!new') {
      resetSession('slack', userId);
      await say('🔄 Session reset! Starting fresh.');
      return;
    }

    if (text.trim() === '!help') {
      await say(
        '*Personal AI Assistant*\n\n' +
        'I can help with:\n' +
        '• 🔍 Web search\n• 💻 Run code\n• 📁 Save & read files\n• 💬 Conversation memory\n\n' +
        'Commands: `!reset` · `!help`'
      );
      return;
    }

    // Download any attached files
    const files = [];
    if (msg.files?.length) {
      for (const file of msg.files) {
        try {
          const data = await downloadFile(file.url_private, botToken);
          files.push({
            name: file.name || 'attachment',
            mimeType: file.mimetype || 'application/octet-stream',
            data,
          });
          if (!text) text = `Process this file: ${file.name}`;
        } catch {
          await say('❌ Failed to download file.');
          return;
        }
      }
    }

    if (!text && files.length === 0) return;

    // Get user info for username
    let username = userId;
    try {
      const userInfo = await client.users.info({ user: userId });
      username = userInfo.user?.display_name || userInfo.user?.real_name || userId;
    } catch { /* continue without username */ }

    try {
      const response = await processMessage({
        sessionId: `slack:${userId}`,
        channel: 'slack',
        userId,
        username,
        text,
        files,
      });

      // Slack allows up to 3000 chars per block
      await say(response.text.slice(0, 3000));
    } catch (err) {
      const errMsg = err instanceof Error ? err.message : 'Unknown error';
      await say(`❌ Error: ${errMsg}`);
    }
  });

  // Handle app mentions in channels
  app.event('app_mention', async ({ event, say }) => {
    const userId = event.user;
    const text = event.text.replace(/<@[A-Z0-9]+>/g, '').trim();

    if (!text) {
      await say(`<@${userId}> Hi! Send me a message to get started. Try \`!help\` for commands.`);
      return;
    }

    try {
      const response = await processMessage({
        sessionId: `slack:${userId}`,
        channel: 'slack',
        userId,
        text,
      });
      await say(`<@${userId}> ${response.text.slice(0, 2900)}`);
    } catch (err) {
      const errMsg = err instanceof Error ? err.message : 'Unknown error';
      await say(`<@${userId}> ❌ Error: ${errMsg}`);
    }
  });

  return {
    name: 'slack',
    async start() {
      await app.start();
      console.log('[Slack] App started (Socket Mode)');
    },
    async stop() {
      await app.stop();
    },
    async send(userId: string, text: string) {
      await app.client.chat.postMessage({
        token: botToken,
        channel: userId,
        text: text.slice(0, 3000),
      });
    },
  };
}

# 🤖 Personal AI Agent

A self-hosted AI assistant with a built-in CLI — run it as a background daemon, manage it from the terminal. Supports Claude, Ollama (local), OpenAI, and any OpenAI-compatible API.

---

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Run the onboarding wizard (sets up config + optionally installs daemon)
npm run onboard

# — or go straight to daemon install —
npm run onboard:daemon
```

That's it. The wizard walks you through everything step by step.

---

## CLI Commands

After `npm run build` (or use `npm run cli -- <cmd>` directly during dev):

| Command | What it does |
|---|---|
| `node dist/cli.js onboard` | Interactive setup wizard |
| `node dist/cli.js onboard --install-daemon` | Setup + install as background service |
| `node dist/cli.js start` | Start agent in background |
| `node dist/cli.js stop` | Stop the running agent |
| `node dist/cli.js restart` | Restart the agent |
| `node dist/cli.js status` | Show PID, provider, model, config summary |
| `node dist/cli.js logs` | Show last 50 log lines |
| `node dist/cli.js logs --follow` | Tail logs live |
| `node dist/cli.js daemon install` | Install as systemd service (auto-start on login) |
| `node dist/cli.js doctor` | Check config + connectivity |

### npm shortcuts

```bash
npm run onboard         # wizard
npm run onboard:daemon  # wizard + daemon install
npm run daemon          # install daemon only
npm run status          # status
npm run stop            # stop
npm run logs            # tail logs
npm run doctor          # check config
```

### WSL tip

On WSL2 with systemd enabled, `--install-daemon` registers a **systemd user service** that auto-starts on login and survives terminal closes. On WSL without systemd, it falls back to a `nohup` background process + `~/.profile` autostart.

Check systemd status anytime:
```bash
systemctl --user status personal-agent
```

---

## Supported LLM Providers

Set `LLM_PROVIDER` in your `.env` (the wizard handles this for you):

| Provider | `LLM_PROVIDER` | Notes |
|---|---|---|
| Anthropic Claude | `anthropic` | Needs `ANTHROPIC_API_KEY` |
| Ollama (local) | `ollama` | Free, needs `ollama serve` running |
| OpenAI | `openai` | Needs `OPENAI_API_KEY` |
| Groq | `openai` | Set `OPENAI_BASE_URL=https://api.groq.com/openai/v1` |
| LM Studio | `openai` | Set `OPENAI_BASE_URL=http://localhost:1234/v1` |
| Mistral | `openai` | Set `OPENAI_BASE_URL=https://api.mistral.ai/v1` |

---

## Features

| Capability | Details |
|---|---|
| **Web Search** | Brave API (free tier) with DuckDuckGo fallback |
| **Code Execution** | Sandboxed JavaScript runner |
| **File Storage** | Save, read, list, delete text files |
| **Conversation Memory** | Per-user session history, persisted to disk |
| **Multi-Channel** | Telegram, Discord, Slack, WebChat |
| **Skills System** | Self-growing knowledge modules |
| **Daemon** | systemd service or background process, auto-restart on crash |

---

## Config

Config is stored in `~/.personal-agent/.env` (set `AGENT_HOME` to override).

| Variable | Required | Description |
|---|---|---|
| `LLM_PROVIDER` | ✅ | `anthropic` / `ollama` / `openai` |
| `LLM_MODEL` | — | Model name (provider-specific) |
| `ANTHROPIC_API_KEY` | if anthropic | Your Anthropic API key |
| `OLLAMA_BASE_URL` | if ollama | Default: `http://localhost:11434` |
| `OPENAI_API_KEY` | if openai | OpenAI or compatible key |
| `OPENAI_BASE_URL` | — | Override for Groq/LM Studio/etc |
| `PORT` | — | HTTP port (default: `3000`) |
| `TELEGRAM_BOT_TOKEN` | — | Telegram bot token |
| `DISCORD_BOT_TOKEN` | — | Discord bot token |
| `BRAVE_API_KEY` | — | Brave Search (recommended) |

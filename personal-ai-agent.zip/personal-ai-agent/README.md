# 🤖 Personal AI Agent

A self-hosted AI assistant powered by Claude — connects to Telegram, Discord, Slack, and a WebChat interface. Supports web search, code execution, file management, and full conversation memory.

---

## Features

| Capability | Details |
|---|---|
| **Web Search** | Brave API (free tier) with DuckDuckGo fallback |
| **Code Execution** | Sandboxed JavaScript runner with console output |
| **File Storage** | Save, read, list, delete text files persistently |
| **Conversation Memory** | Per-user session history, persisted to disk |
| **Multi-Channel** | Telegram, Discord, Slack, WebChat (all share session state) |

---

## Quick Start

### 1. Install

```bash
# Clone or download this project
cd personal-ai-agent

npm install
```

### 2. Configure

```bash
cp .env.example .env
# Edit .env with your API keys
```

The only **required** key is `ANTHROPIC_API_KEY`. All channels are optional.

### 3. Run

```bash
npm run dev   # Development (hot reload)
npm start     # Production (build first with: npm run build)
```

The WebChat UI is available at **http://localhost:3000** immediately.

---

## Channel Setup

### 🌐 WebChat (works immediately — no setup needed)
Just run the agent and open **http://localhost:3000** in your browser.

---

### 📱 Telegram
1. Message **@BotFather** on Telegram
2. Send `/newbot` and follow prompts
3. Copy the bot token to `TELEGRAM_BOT_TOKEN` in `.env`
4. Find your user ID via [@userinfobot](https://t.me/userinfobot)
5. Add to `TELEGRAM_ALLOWED_USERS` (comma-separated) or leave blank for open access
6. Start a chat with your bot and send any message

**Commands:**
- `/help` — Show help
- `/reset` — Clear conversation history

---

### 🎮 Discord
1. Go to [discord.com/developers/applications](https://discord.com/developers/applications)
2. Create a new application → Bot → "Add Bot"
3. Enable **Message Content Intent** under Privileged Gateway Intents
4. Copy token to `DISCORD_BOT_TOKEN`
5. Generate invite URL: OAuth2 → URL Generator → select `bot` scope + these permissions:
   - Send Messages, Read Message History, Use Slash Commands
6. Invite bot to your server
7. Either DM the bot or @mention it in any channel

**Commands:**
- `!help` — Show help
- `!reset` — Clear conversation

---

### 💬 Slack
1. Go to [api.slack.com/apps](https://api.slack.com/apps) → Create New App → From scratch
2. **Socket Mode** → Enable Socket Mode → Generate App-Level Token (with `connections:write` scope) → copy to `SLACK_APP_TOKEN`
3. **OAuth & Permissions** → Bot Token Scopes: `app_mentions:read`, `chat:write`, `im:history`, `im:read`, `im:write`, `files:read`, `users:read`
4. Install to workspace → copy Bot OAuth Token to `SLACK_BOT_TOKEN`
5. **Event Subscriptions** → Enable → Subscribe to: `message.im`, `app_mention`
6. **Basic Information** → Signing Secret → copy to `SLACK_SIGNING_SECRET`
7. DM the bot or @mention it in a channel

---

## Web Search Setup (Recommended)

Get a free Brave Search API key at [brave.com/search/api](https://brave.com/search/api) — free tier includes 2,000 queries/month.

Set `BRAVE_API_KEY` in your `.env`. Without it, the agent falls back to DuckDuckGo's limited instant-answer API.

---

## API Endpoints

| Endpoint | Description |
|---|---|
| `GET /` | WebChat UI |
| `GET /health` | Status, uptime, session counts, active channels |
| `GET /api/sessions` | List all active sessions |
| `WS /ws` | WebSocket for WebChat |

---

## Architecture

```
┌─────────────────────────────────────────────────┐
│                   Gateway (Express)              │
│            http://localhost:3000                 │
└────┬────────────────────────────┬───────────────┘
     │                            │
     ▼                            ▼
┌──────────┐           ┌─────────────────┐
│ WebSocket │           │  REST API /health│
│  /ws      │           │  /api/sessions  │
└────┬─────┘           └─────────────────┘
     │
     ▼
┌────────────────────────────────────────────────┐
│                  Agent (Claude)                 │
│  • web_search    • execute_code                 │
│  • save_file     • read_file                   │
│  • list_files    • delete_file                 │
└────────────────────────────────────────────────┘
     │
     ▼
┌────────────────────────────────────────────────┐
│              Session Manager                    │
│  Per-channel + per-user conversation history   │
│  Persisted to agent-files/sessions.json        │
└────────────────────────────────────────────────┘

Channel Adapters (run independently):
  📱 Telegram ──────────────────────────────┐
  🎮 Discord ───────────────────────────────┤──▶ Agent
  💬 Slack ─────────────────────────────────┘
  🌐 WebChat (via Gateway WebSocket) ───────┘
```

---

## File Storage

Agent-created files are stored in `./agent-files/files/`. Sessions are persisted at `./agent-files/sessions.json`.

Change the location with `FILES_DIR=/path/to/dir` in `.env`.

---

## Security Notes

- **Allowlists**: Set `TELEGRAM_ALLOWED_USERS` and `DISCORD_ALLOWED_USERS` to restrict access.
- **WebChat**: Currently open — for production, add authentication via `GATEWAY_SECRET`.
- **Code sandbox**: The JavaScript executor uses Node's `vm` module. Network and file system access are blocked inside the sandbox.
- **File paths**: Sanitized to prevent path traversal attacks.
- **Slack**: Uses Socket Mode — no public URL needed.

---

## Extending

### Adding a new tool
Create a file in `src/tools/` that exports a `Tool` object, then register it in `src/agent.ts`:

```typescript
export const myTool: Tool = {
  name: 'my_tool',
  description: 'What this tool does',
  input_schema: {
    type: 'object',
    properties: {
      param: { type: 'string', description: 'A parameter' }
    },
    required: ['param']
  },
  async execute({ param }) {
    return `Result for: ${param}`;
  }
};
```

### Adding a new channel
Implement the `ChannelAdapter` interface from `src/types.ts` and register it in `src/index.ts`.

---

## Environment Variables

| Variable | Required | Description |
|---|---|---|
| `ANTHROPIC_API_KEY` | ✅ | Your Anthropic API key |
| `CLAUDE_MODEL` | — | Model to use (default: `claude-opus-4-6`) |
| `PORT` | — | HTTP port (default: `3000`) |
| `TELEGRAM_BOT_TOKEN` | — | Telegram bot token from @BotFather |
| `TELEGRAM_ALLOWED_USERS` | — | Comma-separated Telegram user IDs |
| `DISCORD_BOT_TOKEN` | — | Discord bot token |
| `DISCORD_ALLOWED_USERS` | — | Comma-separated Discord user IDs |
| `SLACK_BOT_TOKEN` | — | Slack bot OAuth token |
| `SLACK_APP_TOKEN` | — | Slack app-level token (Socket Mode) |
| `SLACK_SIGNING_SECRET` | — | Slack signing secret |
| `BRAVE_API_KEY` | — | Brave Search API key (recommended) |
| `FILES_DIR` | — | Directory for file storage (default: `./agent-files`) |
| `MAX_FILE_SIZE_MB` | — | Max upload size in MB (default: `10`) |

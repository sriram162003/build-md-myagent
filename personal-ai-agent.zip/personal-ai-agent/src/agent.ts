// src/agent.ts
// The core AI agent — sends messages to Claude with tools, handles tool calls.

import Anthropic from '@anthropic-ai/sdk';
import { sessionManager } from './session.js';
import { searchTool } from './tools/search.js';
import { codeExecTool } from './tools/codeExec.js';
import { saveFileTool, readFileTool, listFilesTool, deleteFileTool } from './tools/fileHandler.js';
import { ChannelName, IncomingMessage, AgentResponse, Tool, Message } from './types.js';

const client = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

const MODEL = process.env.CLAUDE_MODEL || 'claude-opus-4-6';

const SYSTEM_PROMPT = `You are a personal AI assistant — smart, capable, and always helpful.
You have access to tools for web search, code execution, and file management.
Be concise but thorough. Format responses with markdown when it helps clarity.
When using tools, explain what you're doing briefly. Chain tool calls as needed to complete tasks.
Current date: ${new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}`;

// All available tools
const TOOLS: Tool[] = [
  searchTool,
  codeExecTool,
  saveFileTool,
  readFileTool,
  listFilesTool,
  deleteFileTool,
];

// Convert our tools to Anthropic's format
const anthropicTools: Anthropic.Tool[] = TOOLS.map(t => ({
  name: t.name,
  description: t.description,
  input_schema: t.input_schema as Anthropic.Tool['input_schema'],
}));

// Tool lookup map
const toolMap = new Map(TOOLS.map(t => [t.name, t]));

export async function processMessage(incoming: IncomingMessage): Promise<AgentResponse> {
  const { channel, userId, username, text } = incoming;
  const toolsUsed: string[] = [];

  // Build user message with file context if files were uploaded
  let userContent = text;
  if (incoming.files && incoming.files.length > 0) {
    const fileNames = incoming.files.map(f => f.name).join(', ');
    userContent += `\n\n[Uploaded files: ${fileNames}]`;
    // Save uploaded files automatically
    for (const file of incoming.files) {
      try {
        const content = file.data.toString('utf-8');
        await saveFileTool.execute({ filename: file.name, content });
        userContent += `\n(File "${file.name}" has been saved — you can reference it)`;
      } catch {
        // Binary file or other issue — note it but continue
        userContent += `\n(Note: "${file.name}" could not be auto-saved as text)`;
      }
    }
  }

  // Append user message to session
  const userMessage: Message = { role: 'user', content: userContent };
  sessionManager.addMessage(channel, userId, userMessage);

  const messages = sessionManager.getMessages(channel, userId);
  console.log(`[Agent] ${channel}/${username || userId}: "${text.slice(0, 60)}..."`);

  // Agentic loop — keep calling Claude until it stops using tools
  let currentMessages = [...messages];
  let finalText = '';

  for (let iteration = 0; iteration < 10; iteration++) {
    const response = await client.messages.create({
      model: MODEL,
      max_tokens: 4096,
      system: SYSTEM_PROMPT,
      tools: anthropicTools,
      messages: currentMessages as Anthropic.MessageParam[],
    });

    // Collect text from this response
    const textBlocks = response.content.filter(b => b.type === 'text') as Anthropic.TextBlock[];
    if (textBlocks.length > 0) {
      finalText = textBlocks.map(b => b.text).join('\n');
    }

    // Check stop reason
    if (response.stop_reason === 'end_turn') {
      // Done — append assistant message and break
      sessionManager.addMessage(channel, userId, {
        role: 'assistant',
        content: finalText,
      });
      break;
    }

    if (response.stop_reason !== 'tool_use') {
      // Unexpected stop — use whatever text we have
      sessionManager.addMessage(channel, userId, {
        role: 'assistant',
        content: finalText || 'I encountered an issue processing your request.',
      });
      break;
    }

    // Add assistant message with tool use blocks to conversation
    currentMessages.push({
      role: 'assistant',
      content: response.content,
    } as Anthropic.MessageParam);

    // Execute all tool calls in parallel
    const toolUseBlocks = response.content.filter(b => b.type === 'tool_use') as Anthropic.ToolUseBlock[];
    const toolResults: Anthropic.ToolResultBlockParam[] = [];

    for (const toolUse of toolUseBlocks) {
      const tool = toolMap.get(toolUse.name);
      if (!tool) {
        toolResults.push({
          type: 'tool_result',
          tool_use_id: toolUse.id,
          content: `Error: Unknown tool "${toolUse.name}"`,
          is_error: true,
        });
        continue;
      }

      toolsUsed.push(toolUse.name);
      console.log(`[Agent] Tool call: ${toolUse.name}`, toolUse.input);

      try {
        const result = await tool.execute(toolUse.input as Record<string, unknown>);
        toolResults.push({
          type: 'tool_result',
          tool_use_id: toolUse.id,
          content: result,
        });
      } catch (err) {
        const errMsg = err instanceof Error ? err.message : String(err);
        toolResults.push({
          type: 'tool_result',
          tool_use_id: toolUse.id,
          content: `Tool error: ${errMsg}`,
          is_error: true,
        });
      }
    }

    // Append tool results and continue the loop
    currentMessages.push({
      role: 'user',
      content: toolResults,
    } as Anthropic.MessageParam);
  }

  return {
    text: finalText || "I'm sorry, I wasn't able to generate a response.",
    toolsUsed,
  };
}

export function resetSession(channel: ChannelName, userId: string): void {
  sessionManager.reset(channel, userId);
}

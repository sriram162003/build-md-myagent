// src/index.ts
// Entry point — loads env, starts gateway, starts enabled channel adapters.

import 'dotenv/config';
import { startGateway } from './gateway.js';

if (!process.env.ANTHROPIC_API_KEY) {
  console.error('❌ ANTHROPIC_API_KEY is required. Copy .env.example to .env and fill it in.');
  process.exit(1);
}

const adapters: Array<{ name: string; start: () => Promise<void>; stop: () => Promise<void> }> = [];

async function main() {
  console.log('╔════════════════════════════════════╗');
  console.log('║      Personal AI Agent v1.0.0      ║');
  console.log('╚════════════════════════════════════╝\n');

  // Start HTTP gateway + WebChat
  await startGateway();

  // ── Telegram ──
  if (process.env.TELEGRAM_BOT_TOKEN) {
    try {
      const { createTelegramAdapter } = await import('./channels/telegram.js');
      const telegram = createTelegramAdapter();
      await telegram.start();
      adapters.push(telegram);
      console.log('✅ Telegram: connected');
    } catch (err) {
      console.error('❌ Telegram failed:', err instanceof Error ? err.message : err);
    }
  } else {
    console.log('⏭  Telegram: skipped (no TELEGRAM_BOT_TOKEN)');
  }

  // ── Discord ──
  if (process.env.DISCORD_BOT_TOKEN) {
    try {
      const { createDiscordAdapter } = await import('./channels/discord.js');
      const discord = createDiscordAdapter();
      await discord.start();
      adapters.push(discord);
      console.log('✅ Discord: connected');
    } catch (err) {
      console.error('❌ Discord failed:', err instanceof Error ? err.message : err);
    }
  } else {
    console.log('⏭  Discord: skipped (no DISCORD_BOT_TOKEN)');
  }

  // ── Slack ──
  if (process.env.SLACK_BOT_TOKEN && process.env.SLACK_APP_TOKEN) {
    try {
      const { createSlackAdapter } = await import('./channels/slack.js');
      const slack = createSlackAdapter();
      await slack.start();
      adapters.push(slack);
      console.log('✅ Slack: connected');
    } catch (err) {
      console.error('❌ Slack failed:', err instanceof Error ? err.message : err);
    }
  } else {
    console.log('⏭  Slack: skipped (no SLACK_BOT_TOKEN or SLACK_APP_TOKEN)');
  }

  console.log('\n✨ Agent is ready!\n');

  // Graceful shutdown
  const shutdown = async (signal: string) => {
    console.log(`\n${signal} received — shutting down...`);
    await Promise.allSettled(adapters.map(a => a.stop()));
    process.exit(0);
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

main().catch(err => {
  console.error('Fatal error:', err);
  process.exit(1);
});
